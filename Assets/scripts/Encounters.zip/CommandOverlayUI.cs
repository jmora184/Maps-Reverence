﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

public class CommandOverlayUI : MonoBehaviour
{
    private readonly HashSet<Transform> playerFollowerUnits = new HashSet<Transform>();

    public static CommandOverlayUI Instance { get; private set; }
    public static CommandOverlayUI instance => Instance; // backwards compat

    [Header("References")]
    public Camera commandCam;
    public RectTransform canvasRoot;


    [Header("Crosshair (UI)")]
    [Tooltip("Optional: drag your Canvas Crosshair GameObject here so it hides in command view.")]
    public GameObject crosshairUI;

    [Header("Move Cursor Icon (UI)")]
    [Tooltip("UI Image that follows the mouse during MoveTargeting and swaps sprites for move/attack.")]
    public HoverCursorIconUI hoverCursorIcon;


    [Header("Hover Hint (tooltip)")]
    [Tooltip("Optional tooltip UI shown when hovering over icons.")]
    public bool enableHoverHints = true;
    [Tooltip("Default tooltip messages (used if the prefab doesn't already have UIHoverHintTarget).")]
    public string allyHoverHint = "Select Ally";
    [Tooltip("Tooltip shown when an ally is inactive (won't accept commands until activated in-world).")]
    public string inactiveAllyHoverHint = "<color=#ffcc00>Inactive:</color> Approach and press J";

    [Header("Inactive Ally Icons")]
    [Range(0f, 1f)] public float inactiveAllyIconAlpha = 0.35f;

    public string enemyHoverHint = "Select Enemy";
    public string teamHoverHint = "Select Team";
    public string playerHoverHint = "Player";
    public string bossHoverHint = "Boss";

    [Tooltip("Shown when an ally/team is pinned (engaged) and cannot be commanded.")]
    public string pinnedHoverHint = "<color=#ff3b30>Pinned:</color> Ally engaged in combat";



    [Header("Pinned (Team clustering)")]
    [Tooltip("Team becomes pinned only if a pinned member is within this radius of the team's main cluster center.")]
    public float teamPinRadiusMeters = 20f;

    [Tooltip("Radius used to identify the team's main cluster (ignores far-away outliers/joiners).")]
    public float teamClusterRadiusMeters = 30f;

    [Tooltip("Minimum number of members considered part of the 'main cluster' before the team can be pinned.")]
    public int teamPinMinClusterMembers = 2;
    [Header("Icon Prefabs (UI)")]
    public RectTransform allyIconPrefab;
    public RectTransform enemyIconPrefab;

    [Header("Player Icon (Persistent UI)")]
    public RectTransform playerIcon;
    public Transform playerTarget;
    public float playerIconWorldHeight = 2f;

    [Header("Boss Icon (Persistent UI)")]
    public RectTransform bossIcon;
    public Transform bossTarget;
    public float bossIconWorldHeight = 2.5f;

    [Header("Settings")]
    public float iconWorldHeight = 2f;
    public bool enemyIconsClickable = true;


    [Header("Enemy Team (UI click rules)")]
    [Tooltip("If true, enemies that are parented under an object named with this prefix (ex: EnemyTeam_1) cannot be clicked/selected. Use the Enemy Team icon instead.")]
    public bool makeEnemyTeamMembersUnclickable = true;

    [Tooltip("Parent name prefix that identifies enemies as belonging to an Enemy Team (ex: EnemyTeam_1, EnemyTeam_2...).")]
    public string enemyTeamMemberParentPrefix = "EnemyTeam_";
    [Header("Selected Ring")]
    public string selectedRingChildName = "SelectedRing";
    [Tooltip("Optional second ring for team selection. Add a child under the ally icon named this (ex: TeamSelectedRing).")]
    public string teamSelectedRingChildName = "TeamSelectedRing";

    [Header("Team Star Icon")]
    public RectTransform teamStarIconPrefab;
    public float teamStarWorldHeight = 2.2f;
    public bool selectTeamWhenClickTeamedMember = true;

    [Header("Team Star Bob")]
    [Tooltip("If enabled, team star icons gently bob up and down (UI pixels) like ally/enemy icons.")]
    public bool teamStarBobEnabled = true;
    [Tooltip("Pixels up/down.")]
    public float teamStarBobAmount = 6f;
    [Tooltip("Speed of bob animation.")]
    public float teamStarBobSpeed = 2f;
    [Header("Team Star Bob Sync")]
    [Tooltip("If enabled, team star bob uses the anchor ally icon's current bob offset (so it feels attached). Falls back to its own sine bob if not found.")]
    public bool teamStarBobSyncToAnchorIcon = true;

    private readonly Dictionary<int, float> teamStarBobSeedByTeamId = new();

    // NOTE: Team destination visuals are handled by MoveDestinationMarkerSystem now (single pin per team).
    // The team star remains anchored to the team's Anchor member.

    [Header("Button Panel (optional)")]
    public RectTransform commandButtonPanel;
    public Vector2 buttonPanelScreenOffset = new Vector2(0f, 0f);

    [Header("Join Button Label (optional)")]
    [Tooltip("When a full Team is selected (team star), show 'Recruit' instead of 'Join'.")]
    public string joinLabelWhenSingle = "Join";
    public string joinLabelWhenTeamSelected = "Recruit";

    // Cached references to the Join button label under commandButtonPanel.
    private TMP_Text cachedJoinLabelTMP;
    private Text cachedJoinLabelLegacy;

    [Header("Player Context Panel (optional)")]
    [Tooltip("Optional separate panel shown when clicking the Player icon (personal commands like Follow Me, Hold Fire, etc.).")]
    public PlayerContextCommandPanelUI playerContextPanel;

    [Header("Hint Toast (auto-found if not assigned)")]
    public HintToastUI hintToastUI;
    public float defaultHintDuration = 2f;

    [Header("Join route detection")]
    [Tooltip("How close agent.destination must be to team.Anchor.position to count as a join-route destination.")]
    public float joinRouteDestinationSnap = 1.25f;

    private Canvas canvas;
    private CommandStateMachine sm;

    private readonly Dictionary<Transform, RectTransform> allyIconByUnit = new();
    private readonly Dictionary<Transform, RectTransform> enemyIconByUnit = new();

    // Scene-spawned enemy team icons (UI) that should stay above unit icons.
    private readonly List<RectTransform> enemyTeamIcons = new List<RectTransform>();
    private readonly Dictionary<int, RectTransform> teamStarByTeamId = new();
    private readonly HashSet<Transform> teamedUnits = new();

    private Coroutine hintHideRoutine;

    // After JOIN confirmed (2nd ally chosen), keep panel hidden until primary selection changes.
    private bool suppressButtonPanelAfterJoinTargetChosen;
    private GameObject suppressButtonPanelPrimarySelectionRef;

    // After MOVE destination chosen, keep panel hidden until primary selection changes.
    private bool suppressButtonPanelAfterMoveTargetChosen;
    private GameObject suppressButtonPanelPrimarySelectionRef_Move;

    // Track state transitions (for move confirm suppression in setups that return to UnitSelected)
    private CommandStateMachine.State lastSmState = CommandStateMachine.State.AwaitSelection;

    // Exposed for UI indicator systems (attack targeting, etc.)
    public bool TryGetEnemyIcon(Transform enemy, out RectTransform icon)
    {
        if (enemy != null && enemyIconByUnit != null && enemyIconByUnit.TryGetValue(enemy, out icon))
            return true;

        icon = null;
        return false;
    }


    private void Awake()
    {
        Instance = this;

        canvas = GetComponentInParent<Canvas>();
        if (canvasRoot == null && canvas != null)
            canvasRoot = canvas.transform as RectTransform;

        sm = FindObjectOfType<CommandStateMachine>();
        if (sm != null) lastSmState = sm.CurrentState;

        AutoFindHintToastUI();

        if (commandButtonPanel != null)
            commandButtonPanel.gameObject.SetActive(false);

        AutoFindPlayerContextPanel();
        AutoFindHoverCursorIcon();
    }

    private void OnEnable()
    {
        if (sm == null) sm = FindObjectOfType<CommandStateMachine>();

        if (sm != null)
        {
            sm.OnAddRequested += HandleAddRequested_ForButtonPanel;
            sm.OnSelectionChanged += HandleSelectionChanged_ForButtonPanel;

            sm.OnMoveTargetChosen += HandleMoveTargetChosen_SuppressPanel;

            // Snap star on move target chosen (works for queued or immediate moves)
            // Team destination visuals are handled by MoveDestinationMarkerSystem (single team pin)
            // and DirectionArrowPreview (optional team arrow when selected).
        }

        AutoFindHintToastUI();
        AutoFindPlayerContextPanel();
        AutoFindHoverCursorIcon();
        SetupPlayerIconClick();
    }

    private void OnDisable()
    {
        if (sm != null)
        {
            sm.OnAddRequested -= HandleAddRequested_ForButtonPanel;
            sm.OnSelectionChanged -= HandleSelectionChanged_ForButtonPanel;

            sm.OnMoveTargetChosen -= HandleMoveTargetChosen_SuppressPanel;

            // (no team-star snap subscriptions)
        }
    }

    private void Start()
    {
        AutoFindHintToastUI();
        AutoFindPlayerContextPanel();
        AutoFindHoverCursorIcon();

        if (playerTarget == null)
        {
            var p = GameObject.FindGameObjectWithTag("Player");
            if (p != null) playerTarget = p.transform;
        }

        if (bossTarget == null)
        {
            var b = GameObject.FindGameObjectWithTag("Boss");
            if (b != null) bossTarget = b.transform;
        }

        SetupPlayerIconClick();

        if (playerIcon != null) EnsureHoverHint(playerIcon, playerHoverHint);
        if (bossIcon != null) EnsureHoverHint(bossIcon, bossHoverHint);

        BuildIcons();
    }

    // -------------------- PLAYER CONTEXT PANEL --------------------

    private void AutoFindPlayerContextPanel()
    {
        if (playerContextPanel != null) return;

        // Finds disabled objects too.
        var all = Resources.FindObjectsOfTypeAll<PlayerContextCommandPanelUI>();
        for (int i = 0; i < all.Length; i++)
        {
            var p = all[i];
            if (p == null) continue;
            if (!p.gameObject.scene.IsValid()) continue; // scene objects only

            playerContextPanel = p;
            return;
        }
    }

    private void AutoFindHoverCursorIcon()
    {
        if (hoverCursorIcon != null) return;

        // Finds disabled objects too.
        var all = Resources.FindObjectsOfTypeAll<HoverCursorIconUI>();
        for (int i = 0; i < all.Length; i++)
        {
            var h = all[i];
            if (h == null) continue;
            if (!h.gameObject.scene.IsValid()) continue;

            hoverCursorIcon = h;
            break;
        }

        if (hoverCursorIcon != null && hoverCursorIcon.canvasRoot == null)
            hoverCursorIcon.canvasRoot = canvasRoot;
    }

    private void SetupPlayerIconClick()
    {
        if (playerIcon == null) return;

        AutoFindPlayerContextPanel();
        AutoFindHoverCursorIcon();

        var btn = playerIcon.GetComponent<Button>();
        if (btn == null) return;

        btn.onClick.RemoveAllListeners();
        btn.onClick.AddListener(OnPlayerIconClicked);
    }

    private void OnPlayerIconClicked()
    {
        AutoFindPlayerContextPanel();
        AutoFindHoverCursorIcon();

        // ✅ If we're currently in JOIN targeting (AddTargeting) let the player icon act as the JOIN target.
        // This allows: select Ally -> Join -> click PlayerIcon => ally becomes a Player follower.
        if (sm == null) sm = FindObjectOfType<CommandStateMachine>();
        if (sm != null &&
            sm.CurrentState == CommandStateMachine.State.AddTargeting &&
            sm.JoinArmed &&
            playerTarget != null)
        {
            // Don't pop the player panel while choosing a join target.
            if (playerContextPanel != null && playerContextPanel.IsVisible())
                playerContextPanel.HideImmediate();

            sm.ClickUnitFromUI(playerTarget.gameObject);
            return;
        }

        if (playerContextPanel == null)
        {
            Debug.LogWarning("[CommandOverlayUI] PlayerContextCommandPanelUI not found/assigned.");
            return;
        }

        if (playerIcon == null)
            return;

        // Toggle behavior: click again to close.
        if (playerContextPanel.IsVisible())
        {
            playerContextPanel.HideImmediate();
            return;
        }

        playerContextPanel.ShowUnder(playerIcon, playerTarget);
    }

    // -------------------- HINT TOAST --------------------

    private void AutoFindHintToastUI()
    {
        if (hintToastUI != null) return;

        // Finds disabled objects too.
        var all = Resources.FindObjectsOfTypeAll<HintToastUI>();
        for (int i = 0; i < all.Length; i++)
        {
            var h = all[i];
            if (h == null) continue;
            if (!h.gameObject.scene.IsValid()) continue; // scene objects only

            hintToastUI = h;
            return;
        }
    }

    private void ShowHint(string message, float durationSeconds)
    {
        if (string.IsNullOrWhiteSpace(message)) return;

        AutoFindHintToastUI();

        if (hintToastUI == null)
        {
            Debug.Log($"[Hint] {message}");
            return;
        }

        hintToastUI.Show(message);

        if (hintHideRoutine != null) StopCoroutine(hintHideRoutine);
        hintHideRoutine = StartCoroutine(HideHintAfter(durationSeconds));
    }

    private IEnumerator HideHintAfter(float seconds)
    {
        yield return new WaitForSecondsRealtime(Mathf.Max(0.05f, seconds));

        if (hintToastUI != null)
            hintToastUI.Hide();

        hintHideRoutine = null;
    }

    // -------------------- ICON BUILD / UPDATE --------------------





    private static void BuildKeepSetForTag(Transform iconRoot, Transform tag, HashSet<Transform> keep)
    {
        keep.Clear();
        if (iconRoot == null || tag == null) return;

        // Keep tag, its children, and the parent chain up to the icon root.
        // This ensures nested PlayerTag becomes visible.
        Transform t = tag;
        while (t != null)
        {
            keep.Add(t);
            if (t == iconRoot) break;
            t = t.parent;
        }

        var tagChildren = tag.GetComponentsInChildren<Transform>(true);
        for (int i = 0; i < tagChildren.Length; i++)
        {
            var c = tagChildren[i];
            if (c != null) keep.Add(c);
        }
    }

    private readonly HashSet<Transform> _tmpKeep = new HashSet<Transform>();

    /// <summary>
    /// FPS mode: keep the AllyIcon active but show ONLY the PlayerTag (and its parent chain).
    /// This avoids bringing back all command overlay visuals in FPS.
    /// </summary>
    private void SetIconShowOnlyPlayerTag(RectTransform icon)
    {
        if (icon == null) return;

        var tag = FindDeepChildByName(icon, "PlayerTag");
        if (tag == null) return;

        BuildKeepSetForTag(icon, tag, _tmpKeep);

        // Enable icon root
        icon.gameObject.SetActive(true);

        // Disable everything under icon except the keep set
        var all = icon.GetComponentsInChildren<Transform>(true);
        for (int i = 0; i < all.Length; i++)
        {
            var tr = all[i];
            if (tr == null) continue;
            if (tr == icon) continue;

            bool keep = _tmpKeep.Contains(tr);
            if (tr.gameObject.activeSelf != keep)
                tr.gameObject.SetActive(keep);
        }

        // Ensure the tag itself is enabled
        tag.gameObject.SetActive(true);
    }

    private static Transform FindDeepChildByName(Transform root, string childName)
    {
        if (root == null || string.IsNullOrEmpty(childName)) return null;

        // Includes inactive children
        var all = root.GetComponentsInChildren<Transform>(true);
        for (int i = 0; i < all.Length; i++)
        {
            var t = all[i];
            if (t != null && t.name == childName)
                return t;
        }
        return null;
    }


    private static bool IsUnderParentNamePrefix(Transform t, string prefix)
    {
        if (t == null || string.IsNullOrEmpty(prefix)) return false;

        Transform p = t.parent;
        while (p != null)
        {
            if (!string.IsNullOrEmpty(p.name) && p.name.StartsWith(prefix, StringComparison.Ordinal))
                return true;
            p = p.parent;
        }
        return false;
    }


    // -------------------- PLAYER FOLLOW TAG --------------------

    public bool IsPlayerFollower(Transform ally)
    {
        if (ally == null) return false;
        return playerFollowerUnits.Contains(ally);
    }

    /// <summary>
    /// Toggles the small PlayerTag indicator under an ally icon (used when ally is following the player).
    /// Your AllyIcon prefab should have a child GameObject named "PlayerTag" (disabled by default).
    /// When active, the ally icon becomes NOT clickable/selection-able.
    /// </summary>
    public void SetPlayerFollowerTag(Transform ally, bool active)
    {
        if (ally == null) return;

        if (active) playerFollowerUnits.Add(ally);
        else playerFollowerUnits.Remove(ally);

        if (allyIconByUnit != null && allyIconByUnit.TryGetValue(ally, out RectTransform icon) && icon != null)
        {
            var tag = FindDeepChildByName(icon, "PlayerTag");
            if (tag != null)
                tag.gameObject.SetActive(active);

            // Disable clicking/raycasting when following so the icon can't be selected.
            var btn = icon.GetComponent<Button>();
            if (btn != null) btn.interactable = !active;

            var cg = icon.GetComponent<CanvasGroup>();
            if (cg == null) cg = icon.gameObject.AddComponent<CanvasGroup>();
            cg.blocksRaycasts = !active;
        }
    }

    public void SetPlayerFollowerTags(IEnumerable<Transform> allies, bool active)
    {
        if (allies == null) return;
        foreach (var a in allies)
            SetPlayerFollowerTag(a, active);
    }



    public void BuildIcons()
    {
        ClearAllIcons();

        // Allies
        var allies = GameObject.FindGameObjectsWithTag("Ally");
        for (int i = 0; i < allies.Length; i++)
        {
            var go = allies[i];
            if (go == null) continue;

            var icon = Instantiate(allyIconPrefab, canvasRoot);
            icon.gameObject.SetActive(true);

            EnsureHoverHint(icon, allyHoverHint);

            allyIconByUnit[go.transform] = icon;


            // Ensure PlayerTag starts hidden and icon is clickable by default
            var playerTag = FindDeepChildByName(icon, "PlayerTag");
            if (playerTag != null) playerTag.gameObject.SetActive(false);
            var btnInit = icon.GetComponent<Button>();
            if (btnInit != null) btnInit.interactable = true;
            var cgInit = icon.GetComponent<CanvasGroup>();
            if (cgInit != null) cgInit.blocksRaycasts = true;


            // Bind ally UI helpers (health bar, team tag, etc.)
            var allyUI = icon.GetComponent<AllyHealthIcon>();
            if (allyUI != null) allyUI.Bind(go.transform);

            var btn = icon.GetComponent<Button>();
            if (btn != null)
            {
                btn.onClick.RemoveAllListeners();
                Transform captured = go.transform;
                btn.onClick.AddListener(() => OnUnitClicked(captured));
            }
        }

        // Enemies
        var enemies = GameObject.FindGameObjectsWithTag("Enemy");
        for (int i = 0; i < enemies.Length; i++)
        {
            var go = enemies[i];
            if (go == null) continue;


            bool isEnemyTeamMember = makeEnemyTeamMembersUnclickable && IsUnderParentNamePrefix(go.transform, enemyTeamMemberParentPrefix);

            var icon = Instantiate(enemyIconPrefab, canvasRoot);
            icon.gameObject.SetActive(true);

            EnsureHoverHint(icon, enemyHoverHint);

            enemyIconByUnit[go.transform] = icon;

            AttackTargetIndicatorSystem.Instance?.RegisterEnemyIcon(go.transform, icon);

            // When MoveTargeting, swap hover marker sprite to attack while hovering an enemy icon.
            if (!isEnemyTeamMember)
                HookEnemyHoverEvents(icon, go.transform);

            // Flank bonus hint: bind this enemy transform to the hover-hint component (if present on the prefab).
            icon.GetComponent<EnemyFlankBonusHoverHint>()?.Bind(go.transform);

            // Ensure enemy icons are clickable (even if the prefab has no Button/Image on the root).
            var btn = icon.GetComponent<Button>();
            if (btn == null) btn = icon.gameObject.AddComponent<Button>();

            var rootImg = icon.GetComponent<Image>();
            if (rootImg == null)
            {
                rootImg = icon.gameObject.AddComponent<Image>();
                // Invisible raycast catcher; visuals live on children under IconVisual.
                rootImg.color = new Color(1f, 1f, 1f, 0f);
            }
            rootImg.raycastTarget = true; // allow clicking enemy icons even for team members

            // Make sure the Button has a target graphic (required by some Unity versions).
            btn.targetGraphic = rootImg;

            if (btn != null)
            {
                btn.onClick.RemoveAllListeners();
                Transform captured = go.transform;
                btn.onClick.AddListener(() =>
                {
                    if (sm == null) sm = FindObjectOfType<CommandStateMachine>();

                    // Resolve what this click should target.
                    // - If this enemy is part of an Enemy Team, we resolve to the team/anchor target (so clicks still work).
                    // - Otherwise we resolve to the clicked enemy.
                    var resolvedTargetGO = ResolveAttackTargetGameObject(captured);
                    if (resolvedTargetGO == null) return;

                    // If we're currently choosing a MOVE/ATTACK target, clicking an enemy icon should submit a target.
                    if (sm != null && sm.CurrentState == CommandStateMachine.State.MoveTargeting)
                    {
                        AttackTargetIndicatorSystem.Instance?.RegisterCommittedAttack(sm.CurrentSelection, resolvedTargetGO.transform);
                        sm.SubmitFollowTarget(resolvedTargetGO);
                        return;
                    }

                    // Otherwise, treat as a normal click selection (if enabled).
                    if (enemyIconsClickable)
                        OnUnitClicked(resolvedTargetGO.transform);
                });

                // Keep the component enabled, but optionally block raycasts/interaction for team members.
                btn.interactable = true; // allow clicking enemy icons even for team members

                btn.enabled = true;

                if (isEnemyTeamMember)
                {
                    var cgBlock = icon.GetComponent<CanvasGroup>();
                    if (cgBlock == null) cgBlock = icon.gameObject.AddComponent<CanvasGroup>();
                    cgBlock.blocksRaycasts = true; // keep clickable

                }

            }
        }


        // If we have an active follow group, re-apply PlayerTag indicators after rebuilding icons.
        if (PlayerSquadFollowSystem.Instance != null)
            PlayerSquadFollowSystem.Instance.RefreshFollowerTagsUI();

        // If enemy team icons already exist in the scene, ensure they render on top after rebuilding icons.
        BringExistingEnemyTeamIconsToTop();

    }

    // -------------------- ENEMY HOVER (attack icon preview) --------------------

    // -------------------- ENEMY TEAM ICON (scene-spawned) --------------------

    /// <summary>
    /// Registers a scene-spawned enemy team icon so it can show preview + committed "attack" badges,
    /// just like a single enemy icon. The teamTarget should be a persistent EnemyTeamAnchor/root Transform.
    /// </summary>
    public void RegisterEnemyTeamIcon(Transform teamTarget, RectTransform teamIcon, string hoverHintMessage = "Enemy Team")
    {
        if (teamTarget == null || teamIcon == null) return;

        teamIcon.gameObject.SetActive(true);

        // Ensure the team icon lives under the same parent as unit icons so sibling order actually matters.
        if (canvasRoot != null && teamIcon.transform.parent != canvasRoot)
            teamIcon.SetParent(canvasRoot, false);

        if (!enemyTeamIcons.Contains(teamIcon))
            enemyTeamIcons.Add(teamIcon);

        // Hover hint (optional).
        EnsureHoverHint(teamIcon, hoverHintMessage);

        // Badge system uses a Transform key; teamTarget works the same as a single enemy Transform.
        AttackTargetIndicatorSystem.Instance?.RegisterEnemyIcon(teamTarget, teamIcon);

        // Hover preview (cursor swap + preview badge).
        HookEnemyHoverEvents(teamIcon, teamTarget);

        // Click-to-commit while in MoveTargeting (does nothing in other states).
        HookAttackCommitClick(teamIcon, teamTarget);

        // Make sure this icon renders on top (but below the hover cursor).
        BringOverlayElementToTopBelowCursor(teamIcon);
    }

    private void HookAttackCommitClick(RectTransform icon, Transform target)
    {
        if (icon == null || target == null) return;

        // Ensure the icon can receive pointer events.
        var img = icon.GetComponent<Image>();
        if (img == null)
        {
            img = icon.gameObject.AddComponent<Image>();
            // Invisible raycast catcher; visuals can live on children.
            img.color = new Color(1f, 1f, 1f, 0f);
        }
        img.raycastTarget = true;

        var cg = icon.GetComponent<CanvasGroup>();
        if (cg == null) cg = icon.gameObject.AddComponent<CanvasGroup>();
        cg.blocksRaycasts = true;

        var trigger = icon.GetComponent<EventTrigger>();
        if (trigger == null) trigger = icon.gameObject.AddComponent<EventTrigger>();

        if (trigger.triggers == null)
            trigger.triggers = new List<EventTrigger.Entry>();

        // Prevent duplicates if we register more than once.
        RemoveEventTrigger(trigger, EventTriggerType.PointerClick);

        var click = new EventTrigger.Entry { eventID = EventTriggerType.PointerClick };
        click.callback.AddListener(_ =>
        {
            if (sm == null) sm = FindObjectOfType<CommandStateMachine>();

            if (sm != null && sm.CurrentState == CommandStateMachine.State.MoveTargeting)
            {
                AttackTargetIndicatorSystem.Instance?.RegisterCommittedAttack(sm.CurrentSelection, target);
                var resolvedTargetGO = ResolveAttackTargetGameObject(target);
                if (resolvedTargetGO != null)
                    sm.SubmitFollowTarget(resolvedTargetGO);
                else
                    sm.SubmitFollowTarget(target.gameObject);
            }
        });
        trigger.triggers.Add(click);
    }



    /// <summary>
    /// When clicking an Enemy Team icon, the 'target' Transform is the team root (EnemyTeam_X),
    /// which usually stays at its original spawn position. To issue correct attack orders, we
    /// resolve a live member GameObject from that team and submit that instead.
    /// </summary>
    private GameObject ResolveAttackTargetGameObject(Transform target)
    {
        if (target == null) return null;

        // Enemy team roots are named like EnemyTeam_1, EnemyTeam_2...
        if (!string.IsNullOrEmpty(enemyTeamMemberParentPrefix) && target.name.StartsWith(enemyTeamMemberParentPrefix))
        {
            var member = FindBestEnemyTeamMember(target);
            if (member != null) return member.gameObject;
        }

        return target.gameObject;
    }

    private Transform FindBestEnemyTeamMember(Transform teamRoot)
    {
        if (teamRoot == null) return null;

        // Prefer an actual enemy root (tagged Enemy/Boss) so downstream systems recognize it as a combat target.
        // (If we return a child collider/agent object without the Enemy tag, Attack orders can fall back to
        //  passive auto-aggro, which only triggers when units are already nearby.)
        Transform firstNonAnchor = null;

        // 1) Direct children: prefer tagged Enemy/Boss.
        for (int i = 0; i < teamRoot.childCount; i++)
        {
            var child = teamRoot.GetChild(i);
            if (child == null) continue;

            if (child.name == "Anchor") // ignore optional helper child
                continue;

            if (firstNonAnchor == null)
                firstNonAnchor = child;

            if (child.CompareTag("Enemy") || child.CompareTag("Boss"))
                return child;
        }

        // 2) Descendants: look for any tagged Enemy/Boss.
        var all = teamRoot.GetComponentsInChildren<Transform>(true);
        for (int i = 0; i < all.Length; i++)
        {
            var t = all[i];
            if (t == null || t == teamRoot) continue;
            if (t.name == "Anchor") continue;

            if (t.CompareTag("Enemy") || t.CompareTag("Boss"))
                return t;
        }

        // 3) Fallbacks (legacy behavior): pick something "physical" so at least we target a live member.
        var agent = teamRoot.GetComponentInChildren<NavMeshAgent>(true);
        if (agent != null && agent.transform != teamRoot) return agent.transform;

        var col = teamRoot.GetComponentInChildren<Collider>(true);
        if (col != null && col.transform != teamRoot) return col.transform;

        return firstNonAnchor;
    }


    void HookEnemyHoverEvents(RectTransform enemyIcon, Transform enemyTarget)
    {
        if (enemyIcon == null) return;

        // Ensure the icon can receive pointer events.
        var img = enemyIcon.GetComponent<Image>();
        if (img != null) img.raycastTarget = true;

        var trigger = enemyIcon.GetComponent<EventTrigger>();
        if (trigger == null) trigger = enemyIcon.gameObject.AddComponent<EventTrigger>();

        if (trigger.triggers == null)
            trigger.triggers = new List<EventTrigger.Entry>();

        // Replace any existing entries for these event types (prevents duplicates after rebuilds).
        RemoveEventTrigger(trigger, EventTriggerType.PointerEnter);
        RemoveEventTrigger(trigger, EventTriggerType.PointerExit);

        var enter = new EventTrigger.Entry { eventID = EventTriggerType.PointerEnter };
        enter.callback.AddListener(_ =>
        {
            AutoFindHoverCursorIcon();
            if (sm == null) sm = FindObjectOfType<CommandStateMachine>();
            if (hoverCursorIcon != null && sm != null && sm.CurrentState == CommandStateMachine.State.MoveTargeting)
                hoverCursorIcon.SetOverEnemy(true);
            int _previewCount = 1;
            if (sm != null && sm.CurrentSelection != null) _previewCount = Mathf.Max(1, sm.CurrentSelection.Count);
            AttackTargetIndicatorSystem.Instance?.SetPreview(enemyTarget, _previewCount);
        });
        trigger.triggers.Add(enter);

        var exit = new EventTrigger.Entry { eventID = EventTriggerType.PointerExit };
        exit.callback.AddListener(_ =>
        {
            AutoFindHoverCursorIcon();
            if (sm == null) sm = FindObjectOfType<CommandStateMachine>();
            if (hoverCursorIcon != null && sm != null && sm.CurrentState == CommandStateMachine.State.MoveTargeting)
                hoverCursorIcon.SetOverEnemy(false);
            AttackTargetIndicatorSystem.Instance?.ClearPreview(enemyTarget);
        });
        trigger.triggers.Add(exit);
    }

    private void RemoveEventTrigger(EventTrigger trigger, EventTriggerType type)
    {
        if (trigger == null || trigger.triggers == null) return;

        for (int i = trigger.triggers.Count - 1; i >= 0; i--)
        {
            if (trigger.triggers[i] != null && trigger.triggers[i].eventID == type)
                trigger.triggers.RemoveAt(i);
        }
    }

    // -------------------- HOVER HINT (tooltip) --------------------

    private void EnsureHoverHint(RectTransform rt, string message)
    {
        if (!enableHoverHints) return;
        if (rt == null) return;

        // Use existing target if present, otherwise add it.
        var t = rt.GetComponent<UIHoverHintTarget>();
        if (t == null) t = rt.gameObject.AddComponent<UIHoverHintTarget>();

        t.message = message;

        // Only show in command view if commandCam exists (prevents FPS UI tooltips).
        if (commandCam != null)
            t.onlyWhenCameraEnabled = commandCam;

        // By default anchor to itself.
        t.anchorOverride = null;
    }


    private void LateUpdate()
    {
        if (canvasRoot == null) return;


        // Hide crosshair in command view, show it in FPS view
        if (crosshairUI != null && commandCam != null)
        {
            bool inCommandView = commandCam.enabled;
            // if in command view, crosshair should be OFF
            if (crosshairUI.activeSelf == inCommandView)
                crosshairUI.SetActive(!inCommandView);
        }

        // If we leave command mode, hide the player panel (prevents it lingering in FPS mode).
        if (playerContextPanel != null && playerContextPanel.IsVisible() && commandCam != null && !commandCam.enabled)
            playerContextPanel.HideImmediate();

        Camera uiCam = canvas != null ? canvas.worldCamera : null;
        if (uiCam == null) uiCam = Camera.main;

        if (sm == null) sm = FindObjectOfType<CommandStateMachine>();

        // If we're not in command view, hard-hide the entire overlay icon layer.
        // This prevents enemy/ally/team icons (and hover attack cursor) from appearing in FPS mode.
        bool inCmd = IsInCommandView();
        SetOverlayVisible(inCmd);
        if (!inCmd)
        {
            // Make absolutely sure the hover cursor is hidden.
            AutoFindHoverCursorIcon();
            if (hoverCursorIcon != null)
            {
                hoverCursorIcon.SetVisible(false);
                hoverCursorIcon.SetOverEnemy(false);
            }
            return;
        }

        // Detect MOVE confirmation moment: MoveTargeting -> UnitSelected (some setups)
        if (sm != null)
        {
            if (lastSmState == CommandStateMachine.State.MoveTargeting &&
                sm.CurrentState == CommandStateMachine.State.UnitSelected)
            {
                suppressButtonPanelAfterMoveTargetChosen = true;
                suppressButtonPanelPrimarySelectionRef_Move = sm.PrimarySelected;

                if (commandButtonPanel != null)
                    commandButtonPanel.gameObject.SetActive(false);
            }

            lastSmState = sm.CurrentState;
        }

        UpdateHoverCursorIcon();

        // Update ally/enemy icons
        UpdateIcons(allyIconByUnit, iconWorldHeight, uiCam, false);
        UpdateIcons(enemyIconByUnit, iconWorldHeight, uiCam, true);

        // Update persistent player icon
        if (playerIcon != null && playerTarget != null)
            UpdateWorldAnchoredUI(playerIcon, playerTarget, playerIconWorldHeight, uiCam);

        // Update persistent boss icon
        if (bossIcon != null && bossTarget != null)
            UpdateWorldAnchoredUI(bossIcon, bossTarget, bossIconWorldHeight, uiCam);

        // Sync team stars & disable teamed unit icons
        SyncTeamsAndStars(uiCam);
        UpdateAllyIconClickability();

        // Keep team stars rendered above ally icons
        EnsureTeamStarsRenderOnTopOfAllyIcons();

        // Selection ring highlight
        UpdateSelectionHighlight();

        // Optional command button panel anchoring
        UpdateCommandButtonPanel(uiCam);


        // Keep enemy team icons rendered above unit icons (but below hover cursor)
        EnsureEnemyTeamIconsOnTop();
    }

    private bool IsInCommandView()
    {
        // Prefer CommandCamToggle when available.
        if (CommandCamToggle.Instance != null)
            return CommandCamToggle.Instance.IsCommandMode;

        bool camSays = (commandCam != null && commandCam.enabled);
        bool stateSays = (sm != null && sm.CurrentState != CommandStateMachine.State.Inactive);
        return camSays || stateSays;
    }

    private void SetOverlayVisible(bool visible)
    {
        // Ally/enemy icons
        if (visible)
        {
            // Command mode: show all icons normally
            SetDictIconsActive(allyIconByUnit, true);
            SetDictIconsActive(enemyIconByUnit, true);

            // If followers exist, re-apply their PlayerTag after re-showing icons.
            if (PlayerSquadFollowSystem.Instance != null)
                PlayerSquadFollowSystem.Instance.RefreshFollowerTagsUI();
        }
        else
        {
            // FPS mode: hide everything EXCEPT PlayerTag for player-followers.
            if (allyIconByUnit != null)
            {
                foreach (var kvp in allyIconByUnit)
                {
                    if (kvp.Value == null) continue;

                    if (IsPlayerFollower(kvp.Key))
                    {
                        SetIconShowOnlyPlayerTag(kvp.Value);
                    }
                    else
                    {
                        kvp.Value.gameObject.SetActive(false);
                    }
                }
            }

            SetDictIconsActive(enemyIconByUnit, false);
        }
        // Team stars
        if (teamStarByTeamId != null)
        {
            foreach (var kvp in teamStarByTeamId)
            {
                if (kvp.Value != null)
                    kvp.Value.gameObject.SetActive(visible);
            }
        }

        // Persistent icons
        if (playerIcon != null) playerIcon.gameObject.SetActive(visible);
        if (bossIcon != null) bossIcon.gameObject.SetActive(visible);

        // Command button panel should never linger in FPS.
        if (!visible && commandButtonPanel != null)
            commandButtonPanel.gameObject.SetActive(false);
    }

    private void SetDictIconsActive(Dictionary<Transform, RectTransform> dict, bool active)
    {
        if (dict == null) return;
        foreach (var kvp in dict)
        {
            var rt = kvp.Value;
            if (rt != null && rt.gameObject.activeSelf != active)
                rt.gameObject.SetActive(active);
        }
    }

    private void UpdateHoverCursorIcon()
    {
        AutoFindHoverCursorIcon();
        if (hoverCursorIcon == null) return;

        // Always drive the cursor icon off this overlay's canvasRoot.
        if (canvasRoot != null)
            hoverCursorIcon.canvasRoot = canvasRoot;

        // Ensure the cursor icon is under the SAME parent as the rest of the overlay UI,
        // so it can render above enemy icons.
        if (canvasRoot != null && hoverCursorIcon.transform.parent != canvasRoot)
            hoverCursorIcon.transform.SetParent(canvasRoot, worldPositionStays: false);

        // Pass Canvas reference (helps ScreenSpaceCamera / WorldSpace conversion).
        if (hoverCursorIcon.canvas == null)
            hoverCursorIcon.canvas = canvas;

        bool inCmd = IsInCommandView();
        bool show = inCmd && (sm != null && sm.CurrentState == CommandStateMachine.State.MoveTargeting);
        hoverCursorIcon.SetVisible(show);

        // Make absolutely sure it renders on top.
        var rt = hoverCursorIcon.transform as RectTransform;
        if (rt != null)
            rt.SetAsLastSibling();

        if (!show)
            hoverCursorIcon.SetOverEnemy(false);
    }

    /// <summary>
    /// Ensures a UI element renders above normal icons, but (if possible) stays below the hover cursor icon.
    /// Useful for enemy team icons that should sit "on top" of other unit icons.
    /// </summary>
    public void BringOverlayElementToTopBelowCursor(RectTransform element)
    {
        if (element == null) return;

        // If the hover cursor icon exists and shares the same parent, place this element just before it.
        if (hoverCursorIcon != null && hoverCursorIcon.transform != null && hoverCursorIcon.transform.parent == element.parent)
        {
            int cursorIndex = hoverCursorIcon.transform.GetSiblingIndex();
            element.SetSiblingIndex(Mathf.Clamp(cursorIndex, 0, element.parent.childCount - 1));
            return;
        }


        // Otherwise just put it on top of its parent.
        element.SetAsLastSibling();
    }

    private void BringExistingEnemyTeamIconsToTop()
    {
        // Enemy team icons are spawned by EncounterDirectorPOC and may exist outside this script's control.
        // After BuildIcons, we want them to sit above normal unit icons (but still below the hover cursor).
#if UNITY_2023_1_OR_NEWER
        var bridges = UnityEngine.Object.FindObjectsByType<EnemyTeamIconTargetingBridge>(FindObjectsInactive.Include, FindObjectsSortMode.None);
#else
        var bridges = UnityEngine.Object.FindObjectsOfType<EnemyTeamIconTargetingBridge>(true);
#endif
        if (bridges == null) return;

        for (int i = 0; i < bridges.Length; i++)
        {
            var b = bridges[i];
            if (b == null) continue;
            var rt = b.GetComponent<RectTransform>();
            if (rt != null)
            {
                if (canvasRoot != null && rt.transform.parent != canvasRoot)
                    rt.SetParent(canvasRoot, false);

                if (!enemyTeamIcons.Contains(rt))
                    enemyTeamIcons.Add(rt);

                BringOverlayElementToTopBelowCursor(rt);
            }
        }

    }
    private void EnsureEnemyTeamIconsOnTop()
    {
        if (enemyTeamIcons == null || enemyTeamIcons.Count == 0) return;

        for (int i = enemyTeamIcons.Count - 1; i >= 0; i--)
        {
            var rt = enemyTeamIcons[i];
            if (rt == null)
            {
                enemyTeamIcons.RemoveAt(i);
                continue;
            }

            // If something re-parented it, pull it back under the overlay root.
            if (canvasRoot != null && rt.transform.parent != canvasRoot)
                rt.SetParent(canvasRoot, false);

            BringOverlayElementToTopBelowCursor(rt);
        }
    }



    private void UpdateIcons(Dictionary<Transform, RectTransform> dict, float worldHeight, Camera uiCam, bool isEnemy)
    {
        if (dict == null) return;

        List<Transform> toRemove = null;
        List<RectTransform> toDestroy = null;

        foreach (var kvp in dict)
        {
            Transform t = kvp.Key;
            RectTransform icon = kvp.Value;

            if (t == null || icon == null)
            {
                toRemove ??= new List<Transform>();
                toRemove.Add(t);

                if (icon != null)
                {
                    toDestroy ??= new List<RectTransform>();
                    toDestroy.Add(icon);
                }

                if (isEnemy && t != null && AttackTargetIndicatorSystem.Instance != null)
                    AttackTargetIndicatorSystem.Instance.UnregisterEnemyIcon(t);

                continue;
            }

            UpdateWorldAnchoredUI(icon, t, worldHeight, uiCam);
        }

        if (toDestroy != null)
        {
            for (int i = 0; i < toDestroy.Count; i++)
            {
                if (toDestroy[i] != null)
                    Destroy(toDestroy[i].gameObject);
            }
        }

        if (toRemove != null)
        {
            for (int i = 0; i < toRemove.Count; i++)
                dict.Remove(toRemove[i]);
        }
    }


    private void UpdateWorldAnchoredUI(RectTransform ui, Transform worldTarget, float height, Camera uiCam)
    {
        if (ui == null || worldTarget == null) return;

        Vector3 wpos = worldTarget.position + Vector3.up * height;
        Camera cam = commandCam != null ? commandCam : Camera.main;
        Vector3 screen = cam != null ? cam.WorldToScreenPoint(wpos) : Vector3.zero;

        if (screen.z < 0f)
        {
            ui.gameObject.SetActive(false);
            return;
        }

        ui.gameObject.SetActive(true);

        RectTransform parentRT = ui.parent as RectTransform;
        if (parentRT == null) parentRT = canvasRoot;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            parentRT,
            new Vector2(screen.x, screen.y),
            uiCam,
            out Vector2 localPoint);

        ui.anchoredPosition = localPoint;
    }

    private void UpdateWorldAnchoredUI_Point(RectTransform ui, Vector3 worldPoint, float height, Camera uiCam)
    {
        if (ui == null) return;

        Vector3 wpos = worldPoint + Vector3.up * height;
        Camera cam = commandCam != null ? commandCam : Camera.main;
        Vector3 screen = cam != null ? cam.WorldToScreenPoint(wpos) : Vector3.zero;

        if (screen.z < 0f)
        {
            ui.gameObject.SetActive(false);
            return;
        }

        ui.gameObject.SetActive(true);

        RectTransform parentRT = ui.parent as RectTransform;
        if (parentRT == null) parentRT = canvasRoot;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            parentRT,
            new Vector2(screen.x, screen.y),
            uiCam,
            out Vector2 localPoint);

        ui.anchoredPosition = localPoint;
    }

    // -------------------- SELECTION HIGHLIGHT --------------------

    private void UpdateSelectionHighlight()
    {
        if (sm == null) sm = FindObjectOfType<CommandStateMachine>();
        if (sm == null) return;

        HashSet<Transform> selected = new();
        var cur = sm.CurrentSelection;
        if (cur != null)
        {
            for (int i = 0; i < cur.Count; i++)
            {
                var go = cur[i];
                if (go != null) selected.Add(go.transform);
            }
        }

        HashSet<Transform> selectedAllies = new();
        foreach (var t in selected)
            if (t != null && allyIconByUnit.ContainsKey(t))
                selectedAllies.Add(t);

        bool multiAllySelection = selectedAllies.Count > 1;

        Dictionary<int, bool> fullTeamSelectedById = null;
        if (multiAllySelection && TeamManager.Instance != null)
        {
            fullTeamSelectedById = new Dictionary<int, bool>();
            var teams = TeamManager.Instance.Teams;
            for (int i = 0; i < teams.Count; i++)
            {
                var team = teams[i];
                if (team == null) continue;
                fullTeamSelectedById[team.Id] = IsFullTeamSelected(team, selectedAllies);
            }
        }

        foreach (var kvp in allyIconByUnit)
        {
            bool on = selected.Contains(kvp.Key);
            SetSelectedRing(kvp.Value, on);

            bool teamOn = false;
            if (on && multiAllySelection && TeamManager.Instance != null)
            {
                var team = TeamManager.Instance.GetTeamOf(kvp.Key);
                if (team != null && fullTeamSelectedById != null && fullTeamSelectedById.TryGetValue(team.Id, out bool full) && full)
                    teamOn = true;
            }

            SetTeamSelectedRing(kvp.Value, teamOn);
        }

        foreach (var kvp in enemyIconByUnit)
            SetSelectedRing(kvp.Value, selected.Contains(kvp.Key));
    }

    private void SetSelectedRing(RectTransform icon, bool on)
    {
        if (icon == null) return;
        var ring = icon.Find(selectedRingChildName);
        if (ring != null) ring.gameObject.SetActive(on);
    }

    private void SetTeamSelectedRing(RectTransform icon, bool on)
    {
        if (icon == null) return;
        if (string.IsNullOrEmpty(teamSelectedRingChildName)) return;
        var ring = icon.Find(teamSelectedRingChildName);
        if (ring != null) ring.gameObject.SetActive(on);
    }

    private bool IsFullTeamSelected(Team team, HashSet<Transform> selectedAllies)
    {
        if (team == null || selectedAllies == null) return false;

        int memberCount = 0;
        for (int i = 0; i < team.Members.Count; i++)
        {
            var m = team.Members[i];
            if (m == null) continue;
            memberCount++;
            if (!selectedAllies.Contains(m)) return false;
        }

        return selectedAllies.Count == memberCount;
    }

    private float GetAnchorIconBobOffsetPixels(Transform anchor)
    {
        if (anchor == null) return 0f;
        if (!allyIconByUnit.TryGetValue(anchor, out var icon) || icon == null) return 0f;

        var behaviours = icon.GetComponentsInChildren<MonoBehaviour>(true);
        for (int i = 0; i < behaviours.Length; i++)
        {
            var b = behaviours[i];
            if (b == null) continue;

            var t = b.GetType();
            var fTarget = t.GetField("bobTarget", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
            var fBase = t.GetField("bobBaseLocalPos", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
            if (fTarget == null || fBase == null) continue;

            try
            {
                var bobTarget = fTarget.GetValue(b) as RectTransform;
                if (bobTarget == null) continue;

                object baseObj = fBase.GetValue(b);
                if (baseObj is Vector3 basePos)
                    return bobTarget.localPosition.y - basePos.y;
            }
            catch { }
        }

        return 0f;
    }

    /// <summary>
    /// Ensures Team Star icons render above Ally (and Enemy) icons by pushing them to the end of the sibling list.
    /// Call this after any icon rebuild/updates that might instantiate icons under the same parent.
    /// </summary>
    private void EnsureTeamStarsRenderOnTopOfAllyIcons()
    {
        if (teamStarByTeamId == null || teamStarByTeamId.Count == 0) return;

        // Pushing each star to last sibling guarantees stars draw above ally/enemy icons.
        foreach (var kvp in teamStarByTeamId)
        {
            var star = kvp.Value;
            if (star == null) continue;
            star.SetAsLastSibling();
        }
    }

    // -------------------- TEAM STARS --------------------

    private void SyncTeamsAndStars(Camera uiCam)
    {
        teamedUnits.Clear();

        if (TeamManager.Instance == null) return;
        var teams = TeamManager.Instance.Teams;

        HashSet<int> liveTeamIds = new();

        for (int i = 0; i < teams.Count; i++)
        {
            var team = teams[i];
            if (team == null) continue;

            liveTeamIds.Add(team.Id);

            for (int m = 0; m < team.Members.Count; m++)
                if (team.Members[m] != null)
                    teamedUnits.Add(team.Members[m]);

            if (teamStarIconPrefab == null) continue;

            if (!teamStarByTeamId.TryGetValue(team.Id, out RectTransform star) || star == null)
            {
                star = Instantiate(teamStarIconPrefab, canvasRoot);
                star.gameObject.SetActive(true);
                teamStarByTeamId[team.Id] = star;

                EnsureHoverHint(star, teamHoverHint);
            }

            star.SetAsLastSibling();

            var teamUI = star.GetComponent<TeamIconUI>();
            if (teamUI != null)
                teamUI.Bind(team, OnTeamStarClicked);

            

            // Bind optional orbiting direction arrow (Option B).
            var teamArrow = star.GetComponent<TeamStarDirectionArrowUI>();
            if (teamArrow != null)
                teamArrow.Bind(team, uiCam);

            // Pinned teams (Option 1 - main cluster rule):
            // The team is pinned only if a pinned member is near the team's MAIN CLUSTER center.
            // This prevents a far-away joiner getting into combat from locking the whole team.
            bool teamPinned = IsTeamPinnedByClusterRule(team);

            // Update team star tooltip message.
            var starHint = star.GetComponent<UIHoverHintTarget>();
            if (starHint != null)
                starHint.message = teamPinned ? pinnedHoverHint : teamHoverHint;

            // Disable clicking pinned teams (but keep raycast so tooltip still works).
            var starBtn = star.GetComponent<Button>();
            if (starBtn != null)
            {
                starBtn.interactable = !teamPinned;
                starBtn.enabled = !teamPinned;
            }
            Transform anchor = team.Anchor;
            if (anchor == null && team.Members.Count > 0) anchor = team.Members[0];

            if (anchor != null)
            {
                if (!star.gameObject.activeSelf) star.gameObject.SetActive(true);

                // seed
                if (!teamStarBobSeedByTeamId.TryGetValue(team.Id, out float seed))
                {
                    seed = UnityEngine.Random.Range(0f, 1000f);
                    teamStarBobSeedByTeamId[team.Id] = seed;
                }

                // Team star stays anchored to the team's Anchor ally (the "second ally clicked" in your join flow).
                // The destination is represented by the pinned destination marker + optional arrow.
                // (We are NOT snapping the star to the issued move destination.)
                Vector3 teamPos = anchor.position;
                UpdateWorldAnchoredUI_Point(star, teamPos, teamStarWorldHeight, uiCam);

                if (teamStarBobEnabled)
                {
                    float y = 0f;

                    if (teamStarBobSyncToAnchorIcon)
                        y = GetAnchorIconBobOffsetPixels(anchor);

                    if (Mathf.Approximately(y, 0f))
                        y = Mathf.Sin((Time.unscaledTime + seed) * teamStarBobSpeed) * teamStarBobAmount;

                    star.anchoredPosition += new Vector2(0f, y);
                }
            }
            else
            {
                star.gameObject.SetActive(false);
            }
        }

        // Cleanup removed teams
        var removeIds = new List<int>();
        foreach (var kvp in teamStarByTeamId)
            if (!liveTeamIds.Contains(kvp.Key))
                removeIds.Add(kvp.Key);

        for (int i = 0; i < removeIds.Count; i++)
        {
            int id = removeIds[i];
            if (teamStarByTeamId.TryGetValue(id, out var rt) && rt != null)
                Destroy(rt.gameObject);
            teamStarByTeamId.Remove(id);
            teamStarBobSeedByTeamId.Remove(id);
        }
    }

    private void UpdateAllyIconClickability()
    {
        if (TeamManager.Instance == null) return;

        foreach (var kvp in allyIconByUnit)
        {
            Transform unit = kvp.Key;
            RectTransform icon = kvp.Value;

            if (unit == null || icon == null) continue;

            // Inactive allies do not accept commands until activated in-world (e.g., press J nearby)
            bool isInactiveAlly = false;
            var activationGate = unit.GetComponent<AllyActivationGate>();
            if (activationGate != null && !activationGate.IsActive)
                isInactiveAlly = true;


            var btn = icon.GetComponent<Button>();
            if (btn == null) continue; var team = TeamManager.Instance.GetTeamOf(unit);
            bool isTeamed = team != null;

            bool allowClick = !isTeamed;

            if (isTeamed && team != null)
            {
                allowClick = IsInRouteToTeamAnchor(unit, team);

                if (!allowClick)
                {
                    var marker = unit.GetComponent<JoinRouteMarker>();
                    if (marker != null && marker.inRoute)
                        allowClick = true;
                }
            }

            // While join-targeting, allow clicking teamed allies so they can be chosen as the JOIN target.
            if (sm != null && sm.CurrentState == CommandStateMachine.State.AddTargeting)
                allowClick = true;
            // Pinned units cannot be selected/commanded (v1 driven by AllyController.chasing).
            // We still allow hover (tooltip) even when pinned.
            var pinned = unit.GetComponent<AllyPinnedStatus>();
            bool isPinned = (pinned != null && pinned.IsPinned);
            if (isPinned)
                allowClick = false;


            // While choosing a MOVE destination, lock selection (no selecting other allies).
            bool inMoveTargeting = (sm != null && sm.CurrentState == CommandStateMachine.State.MoveTargeting);
            if (inMoveTargeting)
                allowClick = false;
            // Update tooltip message for pinned/non-pinned.

            // Inactive allies: always disable clicking (but keep icon visible)
            if (isInactiveAlly)
                allowClick = false;

            var hint = icon.GetComponent<UIHoverHintTarget>();
            if (hint != null)
                hint.message = isPinned ? pinnedHoverHint : (isInactiveAlly ? inactiveAllyHoverHint : allyHoverHint);

            // Dim inactive ally icons
            var cg = icon.GetComponent<CanvasGroup>();
            if (cg == null) cg = icon.gameObject.AddComponent<CanvasGroup>();
            cg.alpha = isInactiveAlly ? inactiveAllyIconAlpha : 1f;


            // If the ally icon is not supposed to be clickable (e.g., it belongs to a team),
            // also disable its raycast target so it won't "block" clicks intended for the Team Star icon above it.
            var img = icon.GetComponent<UnityEngine.UI.Image>();
            if (img != null)
            {
                // During MoveTargeting we keep ally icons as raycast targets (even though they are not clickable)
                // so they still count as UI and won't accidentally submit a ground move underneath them.
                img.raycastTarget = inMoveTargeting ? true : allowClick;
            }

            btn.interactable = allowClick;
            btn.enabled = allowClick;
        }
    }

    private List<GameObject> BuildTeamSelection(Team team)
    {
        var sel = new List<GameObject>();
        if (team == null) return sel;

        if (team.Anchor != null && team.Contains(team.Anchor))
            sel.Add(team.Anchor.gameObject);

        for (int i = 0; i < team.Members.Count; i++)
        {
            var m = team.Members[i];
            if (m == null) continue;
            if (team.Anchor != null && m == team.Anchor) continue;
            sel.Add(m.gameObject);
        }

        return sel;
    }

    private void OnTeamStarClicked(Team team)
    {
        if (team == null) return;

        if (sm == null) sm = FindObjectOfType<CommandStateMachine>();
        if (sm == null) return;



        // Player follow pick mode: clicking a Team Star chooses the whole team to follow.
        if (PlayerSquadFollowSystem.Instance != null && PlayerSquadFollowSystem.Instance.IsPickingFollowers)
        {
            var members = new List<Transform>();
            if (team.Anchor != null) members.Add(team.Anchor);
            if (team.Members != null)
            {
                for (int i = 0; i < team.Members.Count; i++)
                {
                    var mbr = team.Members[i];
                    if (mbr == null) continue;
                    if (team.Anchor != null && mbr == team.Anchor) continue;
                    members.Add(mbr);
                }
            }

            PlayerSquadFollowSystem.Instance.ConsumePickOnTeam(members);
            return;
        }
        // ✅ If we're currently choosing a JOIN target, clicking the star should act like clicking the team "anchor"
        // so an unteamed ally can join an already-existing team.
        if (sm.CurrentState == CommandStateMachine.State.AddTargeting)
        {
            Transform anchor = team.Anchor;
            if (anchor == null && team.Members != null && team.Members.Count > 0)
                anchor = team.Members[0];

            if (anchor != null)
                sm.ClickUnitFromUI(anchor.gameObject);

            return;
        }

        // Otherwise: select the whole team.
        if (!sm.TrySetSelectionFromUI(BuildTeamSelection(team)))
        {
            // CommandStateMachine already showed the appropriate hint.
            return;
        }

        // IMPORTANT: Do NOT override the panel anchor to a member Transform.
        // The panel will anchor under the star UI in UpdateCommandButtonPanel.
    }

    private void OnUnitClicked(Transform unit)
    {
        if (unit == null) return;

        if (sm == null) sm = FindObjectOfType<CommandStateMachine>();
        if (sm == null) return;



        // Player follow pick mode: if armed, this click chooses the follower(s) instead of normal selection.
        if (PlayerSquadFollowSystem.Instance != null && PlayerSquadFollowSystem.Instance.IsPickingFollowers)
        {
            if (unit.CompareTag("Ally"))
            {
                PlayerSquadFollowSystem.Instance.ConsumePickOnAlly(unit);
                return;
            }
        }

        // If this ally is currently a player-follower, ignore clicks (followers aren't selectable).
        if (unit.CompareTag("Ally") && IsPlayerFollower(unit))
            return;
        // While choosing a MOVE target, ignore ally icon clicks so the current selection stays locked
        // until a destination (or enemy follow) is chosen.
        if (sm.CurrentState == CommandStateMachine.State.MoveTargeting)
            return;

        // If we're currently choosing a JOIN target, do NOT auto-select the whole team.
        // We need the click to pass through so CommandStateMachine can fire OnAddRequested.
        if (sm.CurrentState == CommandStateMachine.State.AddTargeting)
        {
            sm.ClickUnitFromUI(unit.gameObject);
            return;
        }

        if (unit.CompareTag("Ally") && TeamManager.Instance != null)
        {
            var team = TeamManager.Instance.GetTeamOf(unit);
            if (team != null)
            {
                if (IsInRouteToTeamAnchor(unit, team))
                {
                    string msg = (!string.IsNullOrWhiteSpace(sm.joinInRouteMessage)) ? sm.joinInRouteMessage : "Ally is en route";
                    float dur = sm.joinInRouteDuration > 0 ? sm.joinInRouteDuration : defaultHintDuration;
                    ShowHint(msg, dur);
                    return;
                }

                if (selectTeamWhenClickTeamedMember)
                {
                    if (!sm.TrySetSelectionFromUI(BuildTeamSelection(team)))
                    {
                        // CommandStateMachine already showed the appropriate hint.
                        return;
                    }

                    // IMPORTANT: Do NOT override the panel anchor to a member Transform.
                    // The panel will anchor under the star UI in UpdateCommandButtonPanel.
                    return;
                }
            }
        }

        sm.ClickUnitFromUI(unit.gameObject);
    }

    private bool IsInRouteToTeamAnchor(Transform unit, Team team)
    {
        if (unit == null || team == null) return false;
        if (team.Anchor == null) return false;
        if (!teamedUnits.Contains(unit)) return false;

        var agent = unit.GetComponent<NavMeshAgent>();
        if (agent == null) agent = unit.GetComponentInChildren<NavMeshAgent>();
        if (agent == null || !agent.isActiveAndEnabled) return false;

        if (agent.pathPending) return false;
        if (!agent.hasPath) return false;

        float minRemain = Mathf.Max(agent.stoppingDistance, 0.05f);
        if (agent.remainingDistance <= minRemain) return false;

        float destToAnchor = Vector3.Distance(agent.destination, team.Anchor.position);
        return destToAnchor <= joinRouteDestinationSnap;
    }

    // -------------------- BUTTON PANEL --------------------


    // -------------------- JOIN BUTTON LABEL --------------------

    private void EnsureJoinButtonLabelRefs()
    {
        if (cachedJoinLabelTMP != null || cachedJoinLabelLegacy != null) return;
        if (commandButtonPanel == null) return;

        var buttons = commandButtonPanel.GetComponentsInChildren<Button>(true);
        if (buttons == null) return;

        for (int i = 0; i < buttons.Length; i++)
        {
            var b = buttons[i];
            if (b == null) continue;

            // Prefer name-based match (common: "JoinButton")
            if (!string.IsNullOrWhiteSpace(b.name) &&
                b.name.IndexOf("join", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                cachedJoinLabelTMP = b.GetComponentInChildren<TMP_Text>(true);
                if (cachedJoinLabelTMP == null)
                    cachedJoinLabelLegacy = b.GetComponentInChildren<Text>(true);
                return;
            }

            // Fallback: text-based match
            var tmp = b.GetComponentInChildren<TMP_Text>(true);
            if (tmp != null && string.Equals(tmp.text?.Trim(), "Join", StringComparison.OrdinalIgnoreCase))
            {
                cachedJoinLabelTMP = tmp;
                return;
            }

            var legacy = b.GetComponentInChildren<Text>(true);
            if (legacy != null && string.Equals(legacy.text?.Trim(), "Join", StringComparison.OrdinalIgnoreCase))
            {
                cachedJoinLabelLegacy = legacy;
                return;
            }
        }
    }

    private bool IsFullTeamSelected()
    {
        if (sm == null) return false;
        if (TeamManager.Instance == null) return false;

        var sel = sm.CurrentSelection;
        if (sel == null || sel.Count == 0) return false;

        var primary = sm.PrimarySelected;
        if (primary == null) return false;

        var team = TeamManager.Instance.GetTeamOf(primary.transform);
        if (team == null || team.Members == null) return false;

        // "Team selected" in your UI means the selection list is the entire team.
        return team.Members.Count > 1 && sel.Count == team.Members.Count;
    }

    private void UpdateJoinButtonLabel()
    {
        if (commandButtonPanel == null) return;

        EnsureJoinButtonLabelRefs();

        string desired = IsFullTeamSelected() ? joinLabelWhenTeamSelected : joinLabelWhenSingle;

        if (cachedJoinLabelTMP != null && cachedJoinLabelTMP.text != desired)
            cachedJoinLabelTMP.text = desired;

        if (cachedJoinLabelLegacy != null && cachedJoinLabelLegacy.text != desired)
            cachedJoinLabelLegacy.text = desired;
    }

    private void UpdateCommandButtonPanel(Camera uiCam)
    {
        if (commandButtonPanel == null) return;

        if (sm == null) sm = FindObjectOfType<CommandStateMachine>();
        if (sm == null) return;

        // JOIN suppression
        if (suppressButtonPanelAfterJoinTargetChosen)
        {
            if (sm.PrimarySelected != suppressButtonPanelPrimarySelectionRef)
                suppressButtonPanelAfterJoinTargetChosen = false;
            else
            {
                commandButtonPanel.gameObject.SetActive(false);
                return;
            }
        }

        // MOVE suppression
        if (suppressButtonPanelAfterMoveTargetChosen)
        {
            if (sm.PrimarySelected != suppressButtonPanelPrimarySelectionRef_Move)
                suppressButtonPanelAfterMoveTargetChosen = false;
            else
            {
                commandButtonPanel.gameObject.SetActive(false);
                return;
            }
        }

        if (sm.PrimarySelected == null || sm.CurrentState != CommandStateMachine.State.UnitSelected)
        {
            commandButtonPanel.gameObject.SetActive(false);
            return;
        }

        commandButtonPanel.gameObject.SetActive(true);

        // Keep the Join button label context-aware (Join vs Recruit).
        UpdateJoinButtonLabel();

        // Prefer anchoring under team star UI whenever the primary selected unit belongs to a team.
        RectTransform teamStarUI = null;
        if (TeamManager.Instance != null && sm.PrimarySelected != null)
        {
            var team = TeamManager.Instance.GetTeamOf(sm.PrimarySelected.transform);
            if (team != null)
                teamStarByTeamId.TryGetValue(team.Id, out teamStarUI);
        }

        if (teamStarUI != null && teamStarUI.gameObject.activeInHierarchy)
        {
            // Best case: both under the same RectTransform parent (common setup).
            var panelParent = commandButtonPanel.parent as RectTransform;
            var starParent = teamStarUI.parent as RectTransform;

            if (panelParent != null && starParent != null && panelParent == starParent)
            {
                commandButtonPanel.anchoredPosition = teamStarUI.anchoredPosition + buttonPanelScreenOffset;
                return;
            }

            // Otherwise, convert the star's UI world position into the panel parent's local space.
            RectTransform targetParent = panelParent != null ? panelParent : canvasRoot;
            if (targetParent != null)
            {
                Vector3 starWorld = teamStarUI.TransformPoint(teamStarUI.rect.center);
                Vector3 lp3 = targetParent.InverseTransformPoint(starWorld);
                commandButtonPanel.anchoredPosition = new Vector2(lp3.x, lp3.y) + buttonPanelScreenOffset;
                return;
            }
        }

        // Fallback: anchor under the primary selected unit (world position)
        Transform anchor = sm.PrimarySelected.transform;

        Vector3 wpos = anchor.position + Vector3.up * iconWorldHeight;
        Camera cam = commandCam != null ? commandCam : Camera.main;
        Vector3 screen = cam != null ? cam.WorldToScreenPoint(wpos) : Vector3.zero;

        if (screen.z < 0f)
        {
            commandButtonPanel.gameObject.SetActive(false);
            return;
        }

        RectTransform parentRect = commandButtonPanel.parent as RectTransform;
        if (parentRect == null) parentRect = canvasRoot;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            parentRect,
            new Vector2(screen.x, screen.y),
            uiCam,
            out Vector2 lp);

        commandButtonPanel.anchoredPosition = lp + buttonPanelScreenOffset;
    }

    // -------------------- MOVE TARGET CHOSEN (PANEL SUPPRESSION) --------------------

    // Keep the button panel from instantly popping back up after a move click.
    private void HandleMoveTargetChosen_SuppressPanel(IReadOnlyList<GameObject> selection, Vector3 destination)
    {
        suppressButtonPanelAfterMoveTargetChosen = true;
        suppressButtonPanelPrimarySelectionRef_Move = sm != null ? sm.PrimarySelected : (selection != null && selection.Count > 0 ? selection[0] : null);

        if (commandButtonPanel != null)
            commandButtonPanel.gameObject.SetActive(false);
    }

    // -------------------- PANEL EVENTS --------------------

    private void HandleAddRequested_ForButtonPanel(IReadOnlyList<GameObject> selection, GameObject clickedUnit)
    {
        if (sm == null) return;
        if (clickedUnit == null) return;

        if (sm.JoinArmed && sm.JoinSource != null && clickedUnit != sm.JoinSource)
        {
            suppressButtonPanelAfterJoinTargetChosen = true;
            suppressButtonPanelPrimarySelectionRef = sm.PrimarySelected;

            if (commandButtonPanel != null)
                commandButtonPanel.gameObject.SetActive(false);
        }
    }

    private void HandleSelectionChanged_ForButtonPanel(IReadOnlyList<GameObject> selection)
    {
        suppressButtonPanelAfterJoinTargetChosen = false;
        suppressButtonPanelPrimarySelectionRef = null;

        suppressButtonPanelAfterMoveTargetChosen = false;
        suppressButtonPanelPrimarySelectionRef_Move = null;
    }

    // -------------------- CLEANUP --------------------

    private void ClearAllIcons()
    {
        foreach (var kvp in allyIconByUnit)
            if (kvp.Value != null) Destroy(kvp.Value.gameObject);
        allyIconByUnit.Clear();
        playerFollowerUnits.Clear();

        foreach (var kvp in enemyIconByUnit)
            if (kvp.Value != null) Destroy(kvp.Value.gameObject);
        enemyIconByUnit.Clear();

        foreach (var kvp in teamStarByTeamId)
            if (kvp.Value != null) Destroy(kvp.Value.gameObject);
        teamStarByTeamId.Clear();
    }
    // --- Team clustering helpers (used for pinned team logic) ---

    private Vector3 ComputeTeamCentroid(Team team, Vector3 fallback)
    {
        if (team == null || team.Members == null || team.Members.Count == 0)
            return fallback;

        Vector3 sum = Vector3.zero;
        int count = 0;

        for (int i = 0; i < team.Members.Count; i++)
        {
            var m = team.Members[i];
            if (m == null) continue;
            sum += m.position;
            count++;
        }

        if (count <= 0)
            return fallback;

        return sum / count;
    }



    private Vector3 ComputeTeamMainClusterCenter(Team team, out int clusterCount)
    {
        clusterCount = 0;

        if (team == null || team.Members == null || team.Members.Count == 0)
            return Vector3.zero;

        var members = team.Members;

        // Count non-null members
        int nonNull = 0;
        for (int i = 0; i < members.Count; i++)
            if (members[i] != null) nonNull++;

        if (nonNull == 0) return Vector3.zero;

        if (nonNull == 1)
        {
            for (int i = 0; i < members.Count; i++)
            {
                if (members[i] != null)
                {
                    clusterCount = 1;
                    return members[i].position;
                }
            }
        }

        // Pick an anchor member representing the "main blob":
        // choose the member with the most neighbors within teamClusterRadiusMeters.
        Transform best = null;
        int bestNeighbors = -1;

        for (int i = 0; i < members.Count; i++)
        {
            var a = members[i];
            if (a == null) continue;

            int neighbors = 0;
            for (int j = 0; j < members.Count; j++)
            {
                if (i == j) continue;
                var b = members[j];
                if (b == null) continue;

                if (Vector3.Distance(a.position, b.position) <= teamClusterRadiusMeters)
                    neighbors++;
            }

            if (neighbors > bestNeighbors)
            {
                bestNeighbors = neighbors;
                best = a;
            }
        }

        if (best == null) return Vector3.zero;

        // Compute centroid of the cluster around the anchor.
        Vector3 sum = Vector3.zero;
        int count = 0;

        for (int i = 0; i < members.Count; i++)
        {
            var m = members[i];
            if (m == null) continue;

            if (Vector3.Distance(best.position, m.position) <= teamClusterRadiusMeters)
            {
                sum += m.position;
                count++;
            }
        }

        clusterCount = Mathf.Max(0, count);
        if (count <= 0) return best.position;

        return sum / count;
    }

    private bool IsTeamPinnedByClusterRule(Team team)
    {
        if (team == null || team.Members == null)
            return false;

        Vector3 center = ComputeTeamMainClusterCenter(team, out int clusterCount);

        // Require the "main cluster" to have at least N members before allowing team-level pinning.
        // Prevents a lone, far-away joiner from pinning the whole team.
        if (clusterCount < teamPinMinClusterMembers)
            return false;

        for (int i = 0; i < team.Members.Count; i++)
        {
            var mem = team.Members[i];
            if (mem == null) continue;

            var pinned = mem.GetComponent<AllyPinnedStatus>();
            if (pinned != null && pinned.IsPinned)
            {
                if (Vector3.Distance(mem.position, center) <= teamPinRadiusMeters)
                    return true;
            }
        }

        return false;
    }

}