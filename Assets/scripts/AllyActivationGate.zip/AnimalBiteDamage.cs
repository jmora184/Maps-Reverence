// AnimalBiteDamage.cs
// Trigger-free bite damage using Physics.OverlapSphere.
//
// Notes:
// - This version still HITS INSTANTLY when BeginBite() is called.
// - Adds an optional "facing cone" filter so you can prevent side/back overlaps
//   from counting as a bite (common when the enemy is hugging the player).
//
// Usage:
// - Put this on a mouth/bite point transform.
// - Call BeginBite() / EndBite() from animation events or AnimalController.

using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

[DisallowMultipleComponent]
public class AnimalBiteDamage : MonoBehaviour
{
    [Header("Damage")]
    public int damage = 5;

    [Tooltip("How far from this transform the bite can hit.")]
    public float radius = 1.0f;

    [Tooltip("Seconds between repeat hits on the same target while overlapping.")]
    public float perTargetCooldown = 0.5f;

    [Header("Targets")]
    public LayerMask targetLayers = ~0;

    [Tooltip("Optional tag filter. Leave empty to ignore tags.")]
    public string requiredTag = "Player";

    [Header("Facing Filter (Optional)")]
    [Tooltip("If enabled, the bite only hits targets within a forward-facing cone.")]
    public bool requireFacingCone = false;

    [Tooltip("Cone angle in degrees (e.g., 120 means +/-60 degrees).")]
    [Range(1f, 180f)]
    public float facingConeAngle = 120f;

    [Tooltip("Optional transform to define forward direction (e.g., the animal head). If null, uses this transform.")]
    public Transform forwardReference;

    [Header("Debug")]
    public bool drawGizmo = true;
    public bool logHits = false;

    private bool _active;
    private readonly Dictionary<int, float> _nextHitTime = new Dictionary<int, float>(32);

    private static readonly BindingFlags BF = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

    public void BeginBite()
    {
        _active = true;
        _nextHitTime.Clear();

        // Instant hit (requested behavior)
        DoHitCheck();
    }

    public void EndBite()
    {
        _active = false;
    }

    private void Update()
    {
        if (!_active) return;
        DoHitCheck();
    }

    private void DoHitCheck()
    {
        Collider[] hits = Physics.OverlapSphere(transform.position, radius, targetLayers, QueryTriggerInteraction.Ignore);
        if (hits == null || hits.Length == 0) return;

        float now = Time.time;

        foreach (var c in hits)
        {
            if (c == null) continue;

            // Optional tag filter (checks root too)
            if (!string.IsNullOrEmpty(requiredTag))
            {
                if (!(c.CompareTag(requiredTag) || (c.transform.root != null && c.transform.root.CompareTag(requiredTag))))
                    continue;
            }

            // Optional facing-cone filter (prevents side/back overlaps)
            if (requireFacingCone && !IsWithinFacingCone(c))
                continue;

            int key = (c.transform.root != null) ? c.transform.root.gameObject.GetInstanceID() : c.gameObject.GetInstanceID();

            if (_nextHitTime.TryGetValue(key, out float nextTime) && now < nextTime)
                continue;

            if (ApplyDamage(c))
            {
                _nextHitTime[key] = now + Mathf.Max(0.05f, perTargetCooldown);

                if (logHits)
                    Debug.Log($"[AnimalBiteDamage] Hit '{c.transform.root.name}' for {damage}.", this);
            }
        }
    }

    private bool IsWithinFacingCone(Collider c)
    {
        Transform fwdT = forwardReference != null ? forwardReference : transform;

        // Use closest point to avoid "center behind me but collider in front" weirdness
        Vector3 closest = c.ClosestPoint(transform.position);
        Vector3 toTarget = (closest - fwdT.position);
        toTarget.y = 0f; // keep it simple; remove if you want vertical aiming
        if (toTarget.sqrMagnitude < 0.0001f) return true;

        Vector3 fwd = fwdT.forward;
        fwd.y = 0f;
        fwd.Normalize();
        toTarget.Normalize();

        float halfAngle = Mathf.Clamp(facingConeAngle * 0.5f, 0.5f, 90f);
        float minDot = Mathf.Cos(halfAngle * Mathf.Deg2Rad);

        float dot = Vector3.Dot(fwd, toTarget);
        return dot >= minDot;
    }

    private bool ApplyDamage(Collider c)
    {
        // Preferred: your project's IDamageable interface (already defined elsewhere).
        var dmg = c.GetComponentInParent<IDamageable>();
        if (dmg != null)
        {
            dmg.TakeDamage(damage);
            return true;
        }

        // Fallback: reflection on common damage method names.
        // We scan all MonoBehaviours on parents because colliders are often on children.
        MonoBehaviour[] monos = c.GetComponentsInParent<MonoBehaviour>(true);
        if (monos == null || monos.Length == 0) return false;

        foreach (var mb in monos)
        {
            if (mb == null) continue;
            if (TryInvokeDamageMethod(mb, "TakeDamage", damage)) return true;
            if (TryInvokeDamageMethod(mb, "ApplyDamage", damage)) return true;
            if (TryInvokeDamageMethod(mb, "Damage", damage)) return true;
            if (TryInvokeDamageMethod(mb, "ReceiveDamage", damage)) return true;
            if (TryInvokeDamageMethod(mb, "Hurt", damage)) return true;
        }

        return false;
    }

    private bool TryInvokeDamageMethod(MonoBehaviour target, string methodName, int dmgAmount)
    {
        Type t = target.GetType();

        // First try (int)
        MethodInfo m1 = t.GetMethod(methodName, BF, null, new Type[] { typeof(int) }, null);
        if (m1 != null)
        {
            m1.Invoke(target, new object[] { dmgAmount });
            return true;
        }

        // Then try (float)
        MethodInfo mf = t.GetMethod(methodName, BF, null, new Type[] { typeof(float) }, null);
        if (mf != null)
        {
            mf.Invoke(target, new object[] { (float)dmgAmount });
            return true;
        }

        return false;
    }

    private void OnDrawGizmosSelected()
    {
        if (!drawGizmo) return;
        Gizmos.DrawWireSphere(transform.position, radius);

        if (requireFacingCone)
        {
            Transform fwdT = forwardReference != null ? forwardReference : transform;
            Vector3 fwd = fwdT.forward;
            fwd.y = 0f;
            if (fwd.sqrMagnitude < 0.0001f) return;
            fwd.Normalize();

            float half = facingConeAngle * 0.5f;
            Quaternion left = Quaternion.AngleAxis(-half, Vector3.up);
            Quaternion right = Quaternion.AngleAxis(half, Vector3.up);

            Gizmos.DrawLine(fwdT.position, fwdT.position + left * fwd * radius);
            Gizmos.DrawLine(fwdT.position, fwdT.position + right * fwd * radius);
        }
    }
}
