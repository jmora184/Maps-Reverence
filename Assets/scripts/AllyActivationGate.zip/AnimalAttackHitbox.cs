// AnimalAttackHitbox.cs
// Attach to your BiteHitbox (SphereCollider set to IsTrigger).
//
// Key fixes for your project:
// 1) Your AnimalController is calling BeginSwing/EndSwing -> we provide those methods.
// 2) Your project already defines IDamageable elsewhere, and its TakeDamage likely takes ONE int arg.
//    We therefore call IDamageable.TakeDamage(int) only.
// 3) We avoid hard references to PlayerVitals/EnemyHealthController/AllyHealth/etc (your errors showed method mismatches),
//    and instead use reflection to call common damage methods safely without compile-time coupling.
//
// NOTE: Trigger callbacks require at least one Rigidbody between the two colliders.
// Recommended: add Rigidbody to this hitbox (IsKinematic=true, UseGravity=false).

using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

[DisallowMultipleComponent]
public class AnimalAttackHitbox : MonoBehaviour
{
    [Header("Damage")]
    public int damage = 10;

    [Tooltip("Seconds before this hitbox can damage the same target again.")]
    public float perTargetCooldown = 0.5f;

    [Header("Target Filtering")]
    public bool hitPlayer = true;
    public bool hitEnemy = true;
    public bool hitAlly = false;
    public bool hitNPC = false;

    [Tooltip("Optional: only damage objects on these layers. Default = everything.")]
    public LayerMask allowedLayers = ~0;

    [Header("Attack Window")]
    [Tooltip("If false, hitbox does nothing. Toggle via BeginSwing/EndSwing or animation events.")]
    public bool hitboxActive = false;

    [Header("Debug")]
    public bool logHits = false;

    private readonly Dictionary<int, float> _nextDamageTimeByTarget = new Dictionary<int, float>(64);
    private Collider _col;

    private static readonly BindingFlags BF = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

    private void Awake()
    {
        _col = GetComponent<Collider>();
        if (_col == null)
        {
            Debug.LogError($"{nameof(AnimalAttackHitbox)} on {name} requires a Collider.", this);
            enabled = false;
            return;
        }

        if (!_col.isTrigger)
            Debug.LogWarning($"{nameof(AnimalAttackHitbox)}: Collider on {name} should be set to IsTrigger.", this);
    }

    // --- Animation event hooks (your AnimalController expects these names) ---
    public void BeginSwing() => hitboxActive = true;
    public void EndSwing() => hitboxActive = false;

    // Optional nicer names if you prefer to call them directly from animations:
    public void EnableHitbox() => hitboxActive = true;
    public void DisableHitbox() => hitboxActive = false;

    private void OnEnable() => _nextDamageTimeByTarget.Clear();

    private void OnTriggerEnter(Collider other) => TryDamage(other);
    private void OnTriggerStay(Collider other) => TryDamage(other);

    private void TryDamage(Collider other)
    {
        if (!hitboxActive) return;
        if (other == null) return;

        // Layer filter
        if (((1 << other.gameObject.layer) & allowedLayers.value) == 0)
            return;

        // Ignore self / same hierarchy
        if (other.transform == transform || other.transform.IsChildOf(transform) || transform.IsChildOf(other.transform))
            return;

        Transform root = other.transform.root;
        string tag = other.CompareTag("Untagged") ? (root != null ? root.tag : other.tag) : other.tag;

        if (!IsTagAllowed(tag))
            return;

        int key = (root != null ? root.gameObject.GetInstanceID() : other.gameObject.GetInstanceID());
        float now = Time.time;

        if (_nextDamageTimeByTarget.TryGetValue(key, out float nextTime) && now < nextTime)
            return;

        if (ApplyDamage(other))
        {
            _nextDamageTimeByTarget[key] = now + Mathf.Max(0.05f, perTargetCooldown);

            if (logHits)
            {
                string hitName = root != null ? root.name : other.name;
                Debug.Log($"[{nameof(AnimalAttackHitbox)}] Hit {hitName} for {damage}.", this);
            }
        }
    }

    private bool IsTagAllowed(string tag)
    {
        if (hitPlayer && tag == "Player") return true;
        if (hitEnemy && tag == "Enemy") return true;
        if (hitAlly && tag == "Ally") return true;
        if (hitNPC && tag == "NPC") return true;
        return false;
    }

    private bool ApplyDamage(Collider other)
    {
        // 1) Preferred: your project's existing IDamageable interface (likely TakeDamage(int)).
        //    This compiles only if IDamageable exists in your project (it does, per your error).
        var dmg = other.GetComponentInParent<IDamageable>();
        if (dmg != null)
        {
            // Your error showed "No overload for TakeDamage takes 2 arguments" -> call ONE arg.
            dmg.TakeDamage(damage);
            return true;
        }

        // 2) Fallback: reflection on common method names without compile-time dependencies.
        //    We try on the parent/root first because child colliders often have no scripts.
        var target = other.GetComponentInParent<MonoBehaviour>();
        if (target == null && other.transform.root != null)
            target = other.transform.root.GetComponentInChildren<MonoBehaviour>();

        if (target == null) return false;

        Transform attacker = transform.root;

        // Try several common method signatures/names.
        return TryInvokeDamageMethod(target, "TakeDamage", damage, attacker)
            || TryInvokeDamageMethod(target, "ApplyDamage", damage, attacker)
            || TryInvokeDamageMethod(target, "Damage", damage, attacker)
            || TryInvokeDamageMethod(target, "ReceiveDamage", damage, attacker);
    }

    private bool TryInvokeDamageMethod(MonoBehaviour target, string methodName, int dmgAmount, Transform attacker)
    {
        if (target == null) return false;

        Type t = target.GetType();

        // Prefer (int, Transform)
        MethodInfo m2 = t.GetMethod(methodName, BF, null, new Type[] { typeof(int), typeof(Transform) }, null);
        if (m2 != null)
        {
            m2.Invoke(target, new object[] { dmgAmount, attacker });
            return true;
        }

        // Then (int)
        MethodInfo m1 = t.GetMethod(methodName, BF, null, new Type[] { typeof(int) }, null);
        if (m1 != null)
        {
            m1.Invoke(target, new object[] { dmgAmount });
            return true;
        }

        return false;
    }
}
