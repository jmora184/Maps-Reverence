using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class UIController : MonoBehaviour
{
    public static UIController instance;

    public Slider healthSlider;
    public Text healthText,ammoText;
    public Image damageEffect;
    public float damageAlpha = .25f, damageFadeSpeed = 2f;
    public GameObject pauseScreen;
    //public GameObject mini;
    public Image blackScreen;
    public float fadeSpeed = 1.5f;

    private void Awake()
    {
        instance = this;

    }
    // Start is called before the first frame update
    void Start()
    {
        //Vector2 screenPoint = WorldToCanvasPosition(canvas, cam, objectToFollow.position);

        //Vector3 pos = buttonA.transform.position;
        //buttonA.transform.position = screenPoint;
    }

    // Update is called once per frame
    void Update()
    {
  
        if (damageEffect.color.a != 0)
        {
            damageEffect.color = new Color(damageEffect.color.r, damageEffect.color.g, damageEffect.color.b, Mathf.MoveTowards(damageEffect.color.a, 0f, damageFadeSpeed *Time.deltaTime));
        }

        if (!GameManager.instance.levelEnding)
        {
            blackScreen.color = new Color(blackScreen.color.r, blackScreen.color.g, blackScreen.color.b, Mathf.MoveTowards(blackScreen.color.a, 0f, fadeSpeed * Time.deltaTime));
        }
        else
        {
            blackScreen.color = new Color(blackScreen.color.r, blackScreen.color.g, blackScreen.color.b, Mathf.MoveTowards(blackScreen.color.a, 1f, fadeSpeed * Time.deltaTime));
        }


    }




    public void ShowDamage()
    {
        damageEffect.color = new Color(damageEffect.color.r, damageEffect.color.g, damageEffect.color.b, .25f);
    }

    public void ExplodeView()
    {
        //mini.gameObject.transform.localScale += new Vector3(3, 3, 3);
    }
}
