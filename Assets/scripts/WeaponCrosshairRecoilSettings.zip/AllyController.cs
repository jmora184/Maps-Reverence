﻿// 1/4/2026 AI-Tag
// This was created with the help of Assistant, a Unity Artificial Intelligence product.

using System;
using System.Collections;
using System.Reflection;
using UnityEngine;
using UnityEngine.AI;
using Random = UnityEngine.Random;

public class AllyController : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed;
    [Tooltip("How quickly the ally turns to face its movement direction when not in combat.")]
    public float moveTurnSpeed = 12f;
    [Tooltip("If target is set (e.g., joining a team), we will keep updating destination to follow it.")]
    public float travelFollowUpdateInterval = 0.15f;
    public Rigidbody theRB;
    public Transform target; // (used for dynamic travel follow, e.g., join in-route)
    private bool chasing;

    /// <summary>True while this ally is actively chasing/fighting an enemy.</summary>
    public bool IsChasing => chasing;

    private float travelFollowTimer;
    public float distanceToChase = 10f, distanceToLose = 15f, distanceToStop = 2f;

    [Header("Commanded Attack Chase Override")]
    [Tooltip("If true, a direct Attack order will keep chasing the target even if it's beyond distanceToLose.")]
    public bool allowCommandedAttackChaseBeyondLose = true;

    [Tooltip("How long (seconds) a commanded attack may ignore distanceToLose. Set 0 for unlimited.")]
    public float commandedAttackChaseMaxSeconds = 0f;

    private bool _hasCommandedAttack;
    private float _commandedAttackUntilTime;
    private Transform _commandedAttackTarget;

    public NavMeshAgent agent;

    [Header("Water Slow")]
    [Tooltip("If true, this unit's NavMeshAgent speed is multiplied while inside a WaterSlowZone trigger.")]
    public bool enableWaterSlow = true;
    [Range(0.05f, 1f)]
    public float defaultWaterSpeedMultiplier = 0.65f;

    // Runtime multiplier set by WaterSlowZone (1 = normal).
    private float _waterSpeedMultiplier = 1f;

    // Fallback baseline when no AllyCombatStats is present.
    private float _baseAgentSpeedFallback = 0f;

    [Header("Combat")]
    public GameObject bullet;
    public Transform firePoint;

    [Header("Muzzle Flash (Simple Toggle)")]
    [Tooltip("Assign your Muzzle Flash GameObject (mesh spheres/cubes). It can live anywhere; we'll move it to firePoint when firing.")]
    public GameObject muzzleFlashObject;
    [Range(0.005f, 0.2f)]
    [Tooltip("How long the muzzle flash stays visible per shot (seconds). Typical 0.03 - 0.08")]
    public float muzzleFlashDuration = 0.05f;
    [Tooltip("If true, we snap the muzzle flash object to firePoint position/rotation when firing.")]
    public bool muzzleFlashFollowFirePoint = true;
    [Tooltip("Optional local offset from firePoint when snapping.")]
    public Vector3 muzzleFlashLocalOffset = Vector3.zero;
    private Coroutine _muzzleFlashRoutine;
    public float fireRate = 0.5f;
    private float fireCount;

    [Header("Aim")]
    [Tooltip("If the target has a child transform with this name, the ally will aim at it (recommended).")]
    public string aimPointChildName = "AimPoint";

    [Tooltip("If true, the ally will aim at the target's Collider bounds center when no AimPoint is found.")]
    public bool useColliderBoundsForAim = true;

    [Tooltip("Fallback vertical offset added to target.position when no AimPoint/Collider is found.")]
    public float aimHeightOffset = 1.2f;

    [Header("Combat Range")]
    [Tooltip("Preferred distance to keep from the enemy while fighting.")]
    public float desiredAttackRange = 6f;

    [Tooltip("Enable a minimum/maximum preferred combat distance band (ex: keep between 20 and 60). If disabled, the ally uses desiredAttackRange as a single ideal distance.")]
    public bool enableDesiredAttackRangeBand = false;

    [Tooltip("If enableDesiredAttackRangeBand is true: the ally will back off if closer than this distance.")]
    public float desiredAttackRangeMin = 20f;

    [Tooltip("If enableDesiredAttackRangeBand is true: the ally will move in if farther than this distance.")]
    public float desiredAttackRangeMax = 60f;

    [Tooltip("Small buffer around desiredAttackRange to prevent jitter (hysteresis).")]
    public float attackRangeBuffer = 0.75f;
    [Header("Shooting Range Gate")]
    [Tooltip("If true, the ally will ONLY fire when within its desired attack range (or the min/max band) plus buffers.")]
    public bool onlyShootWhenInDesiredAttackRange = true;

    [Tooltip("Extra buffer (meters) added on top of attackRangeBuffer when deciding if we are close enough to shoot.")]
    public float shootRangeExtraBuffer = 0.5f;


    [Header("Dynamic Desired Range")]
    [Tooltip("If true, this ally will periodically pick a new preferred attack distance (desiredAttackRange) so fights feel less robotic and squads don't clump at the exact same radius.")]
    public bool enableDynamicDesiredAttackRange = false;

    [Tooltip("Minimum seconds between picking a new desired attack range.")]
    public float desiredAttackRangeUpdateIntervalMin = 1.8f;

    [Tooltip("Maximum seconds between picking a new desired attack range.")]
    public float desiredAttackRangeUpdateIntervalMax = 3.2f;

    [Tooltip("When NOT using the min/max band, randomize desired range by +/- this amount around desiredAttackRange.")]
    public float desiredAttackRangeJitter = 1.5f;

    [Tooltip("If true, desired range is only re-picked while actively chasing (recommended).")]
    public bool desiredAttackRangeUpdateOnlyWhenChasing = true;

    [Tooltip("NavMesh sample radius used when backing away from a target.")]
    public float backoffSampleRadius = 2.5f;

    [Tooltip("How quickly the unit turns to face the target while fighting.")]
    public float faceTargetTurnSpeed = 12f;

    [Header("Combat Dodge / Strafing")]
    [Tooltip("If true, the unit will strafe/circle while shooting instead of standing still at ideal range.")]
    public bool enableCombatStrafe = true;

    [Tooltip("How often (seconds) we pick a new strafe point around the target.")]
    public float strafeRepathInterval = 0.35f;

    [Tooltip("Seconds between changing strafe direction/angle.")]
    public float strafeChangeInterval = 1.25f;

    [Tooltip("Max random angle jitter added to the strafe direction (degrees).")]
    public float strafeAngleJitter = 25f;

    [Tooltip("NavMesh sample radius used when picking a strafe point.")]
    public float strafeSampleRadius = 2.5f;

    [Tooltip("Distance (meters) moved during each short combat burst (diagonal strafe/back-forward).")]
    public float combatBurstMoveDistance = 2.0f;

    [Tooltip("How much the burst includes moving toward/away from the target (0 = purely sideways).")]
    public float combatBurstRadialWeight = 0.65f;

    [Tooltip("How much the burst includes moving sideways around the target (0 = no strafing).")]
    public float combatBurstTangentialWeight = 1.0f;

    [Header("Formation Hold (Optional)")]
    [Tooltip("If true, and this ally is currently following a formation slot (target != null), combat movement is clamped so the ally stays near its slot instead of breaking formation.")]
    public bool holdFormationWhenFollowing = true;

    [Tooltip("Max distance (meters) the ally may drift away from its formation slot during combat.")]
    public float formationCombatTetherRadius = 2.5f;

    [Tooltip("If true, tether radius scales slightly with team size (helps large squads keep a cohesive line).")]
    public bool scaleTetherWithTeamSize = true;

    [Tooltip("Extra meters added to tether when scaling with team size. Effective tether = base + extra * sqrt(teamSize-1).")]
    public float tetherExtraPerSqrtMember = 0.35f;

    [Header("Manual Move Hold (Player Move Orders)")]
    [Tooltip("If true, a player-issued Move order creates a 'hold zone'. While holding, the ally will not chase enemies outside manualChaseLeashRadius from the hold point.")]
    public bool enableManualHoldZone = true;

    [Tooltip("Radius around the move destination that counts as the ally's 'hold area'. Used mainly for editor tuning / future UI. Combat leash uses manualChaseLeashRadius.")]
    public float manualHoldRadius = 6f;

    [Tooltip("Max distance from the hold point this ally is allowed to chase during combat (prevents chasing 50+ units away after a Move order).")]
    public float manualChaseLeashRadius = 12f;

    [Tooltip("If false, allies will NOT auto-acquire enemies while holding (they'll only fight if explicitly attacked/ordered).")]
    public bool manualHoldAllowsAutoAggro = true;

    [Header("Team Focus Fire")]
    [Tooltip("If true, allies in a team will sometimes prefer the same target as a nearby teammate (reduces split fire).")]
    public bool enableTeamFocusFire = true;

    [Tooltip("Max distance from this ally to a teammate's target for focus-fire to kick in.")]
    public float focusFireMaxTargetDistance = 12f;

    [Tooltip("Seconds between allowed focus-fire target switches (prevents oscillation).")]
    public float focusFireCooldown = 1.0f;

    [Header("Combat Engagement Pause")]
    [Tooltip("When the ally is in its desired range, it will pause (stand ground) for a bit while shooting instead of constantly strafing.")]
    public bool pauseWhileShootingInRange = true;

    [Tooltip("When the ally receives a direct Attack order (ForceCombatTarget), temporarily disable the pause behavior so it keeps repositioning/straffing instead of standing still.")]
    public float forceStrafeAfterAttackOrderSeconds = 6f;

    [Tooltip("Min seconds to stand still while shooting (in-range).")]
    public float pauseShootMinSeconds = 2f;

    [Tooltip("Max seconds to stand still while shooting (in-range).")]
    public float pauseShootMaxSeconds = 3f;

    [Tooltip("After a pause, allow a short burst of strafing movement before pausing again (keeps combat from looking too robotic).")]
    public float pauseMoveBurstSeconds = 0.5f;

    [Header("Animation")]
    public Animator soldierAnimator;

    [Header("Animation Params")]
    [Tooltip("Bool parameter used to drive Idle/Run transitions (optional). Set to match your Animator Controller.")]
    public string runBoolParam = "isRunning";

    [Tooltip("Float parameter used for blend trees (optional). Set to match your Animator Controller.")]
    public string speedFloatParam = "Speed";

    // Animator parameter caching (avoids spamming errors if a param doesn't exist)
    private bool _animHasIsRunning;
    private int _animIsRunningHash;
    private bool _animHasSpeed;
    private int _animSpeedHash;

    [Header("Move Marker Auto-Clear")]
    [Tooltip("When close enough to the pinned destination, auto-clear the move marker for this ally.")]
    public bool autoClearMoveMarkerOnArrival = true;

    [Tooltip("Extra distance beyond stoppingDistance to consider 'arrived' for marker clearing.")]
    public float markerArrivalBuffer = 0.15f;

    [Tooltip("If true, allies that are currently in a team will use a larger arrival buffer (helps prevent stacking when moving a newly formed team).")]
    public bool useTeamArrivalBufferMultiplier = true;

    [Tooltip("Multiplier applied to markerArrivalBuffer when this ally is in a team. Set to 2 to double the buffer area.")]
    public float teamArrivalBufferMultiplier = 2f;

    // Per-ally stats (team size -> multipliers)
    private AllyCombatStats combatStats;

    // Pinned state (v1 driven by 'chasing')
    private AllyPinnedStatus pinnedStatus;

    // Track one enemy target so we don't fight every enemy in the scene at once
    private Transform currentEnemy;

    /// <summary>The enemy this ally is currently chasing (null when idle).</summary>
    public Transform CurrentEnemy => currentEnemy;

    // Manual hold runtime
    private bool _hasManualHold;
    private Vector3 _manualHoldPoint;

    // Focus fire runtime
    private float _nextFocusFireTime;

    // Combat pause runtime
    private float _combatPauseTimer;
    private float _combatMoveBurstTimer;
    private float _forceStrafeUntilTime;

    // Dynamic desired range runtime
    private float _currentDesiredAttackRangeRuntime;
    private float _nextDesiredAttackRangeUpdateTime;

    // Combat strafe runtime
    private float _strafeRepathTimer;
    private float _strafeChangeTimer;
    private int _strafeSide = 1; // 1 = right, -1 = left
    private float _strafeAngleOffset;
    // Remember where we were going before we got pulled into combat
    // NOTE: for TEAM moves, the "current" destination can change while we are fighting.
    // So we prefer to resume using the latest pinned destination from MoveDestinationMarkerSystem when available.
    private Vector3 resumeDestination;
    private bool hasResumeDestination;
    private bool resumeWasFollowing;

    private void Awake()
    {
        if (agent == null) agent = GetComponent<NavMeshAgent>();
        if (theRB == null) theRB = GetComponent<Rigidbody>();
        if (soldierAnimator == null) soldierAnimator = GetComponentInChildren<Animator>();

        // Root motion can "pin" the character in place (idle) even when a NavMeshAgent is trying to move it.
        // Disable it so the agent fully controls translation.
        if (soldierAnimator != null)
            soldierAnimator.applyRootMotion = false;

        // We'll handle rotation ourselves:
        // - normal travel: face movement direction
        // - combat: face the target smoothly
        if (agent != null)
            agent.updateRotation = false;

        CacheAnimatorParams();

        combatStats = GetComponent<AllyCombatStats>();
        pinnedStatus = GetComponent<AllyPinnedStatus>();

        // De-sync strafing so squads don't move in unison when they start attacking on the same frame.
        _strafeRepathTimer = Random.Range(0f, Mathf.Max(0.05f, strafeRepathInterval));
        _strafeChangeTimer = Random.Range(0f, Mathf.Max(0.1f, strafeChangeInterval));
        _strafeSide = (Random.value < 0.5f) ? -1 : 1;
        _strafeAngleOffset = Random.Range(-strafeAngleJitter, strafeAngleJitter);

        // Ensure muzzle flash starts hidden.
        if (muzzleFlashObject != null)
            muzzleFlashObject.SetActive(false);
    }

    private void CacheAnimatorParams()
    {
        _animHasIsRunning = false;
        _animHasSpeed = false;

        if (soldierAnimator == null) return;

        _animIsRunningHash = Animator.StringToHash(string.IsNullOrEmpty(runBoolParam) ? "isRunning" : runBoolParam);
        _animSpeedHash = Animator.StringToHash(string.IsNullOrEmpty(speedFloatParam) ? "Speed" : speedFloatParam);

        // Cache whether these parameters exist so we don't log errors every frame.
        var ps = soldierAnimator.parameters;
        for (int i = 0; i < ps.Length; i++)
        {
            var p = ps[i];
            if (!_animHasIsRunning && p.type == AnimatorControllerParameterType.Bool && p.name == (string.IsNullOrEmpty(runBoolParam) ? "isRunning" : runBoolParam))
                _animHasIsRunning = true;
            if (!_animHasSpeed && p.type == AnimatorControllerParameterType.Float && p.name == (string.IsNullOrEmpty(speedFloatParam) ? "Speed" : speedFloatParam))
                _animHasSpeed = true;
        }
    }

    private void Start()
    {
        // Initialize agent speed.
        // IMPORTANT: don't accidentally override a NavMeshAgent speed you tuned in the Inspector.
        // If moveSpeed is 0, we treat the agent's current speed as the baseline.
        if (agent != null)
        {
            if (combatStats != null)
            {
                // Prefer explicit moveSpeed if you set it, otherwise keep the current agent.speed.
                float baseline = agent.speed;
                if (moveSpeed > 0f) baseline = moveSpeed;

                if (combatStats.baseMoveSpeed <= 0f)
                    combatStats.baseMoveSpeed = baseline;

                combatStats.ApplyToAgent(agent);
            }
            else if (moveSpeed > 0f)
            {
                agent.speed = moveSpeed;
            }
        }

        // Initialize dynamic desired range (optional)
        InitializeDesiredAttackRangeRuntime();
    }

    /// <summary>
    /// Called by WaterSlowZone triggers. Multiplier is clamped and applied on top of team-size speed scaling.
    /// </summary>
    public void SetWaterSlow(bool inWater, float speedMultiplier)
    {
        if (!enableWaterSlow) return;

        if (inWater)
            _waterSpeedMultiplier = Mathf.Clamp(speedMultiplier > 0f ? speedMultiplier : defaultWaterSpeedMultiplier, 0.05f, 1f);
        else
            _waterSpeedMultiplier = 1f;
    }

    private float GetWaterMult()
    {
        return enableWaterSlow ? _waterSpeedMultiplier : 1f;
    }

    // -------------------- MANUAL HOLD API --------------------
    public void SetManualHoldPoint(Vector3 point)
    {
        _hasManualHold = true;
        _manualHoldPoint = point;
    }

    public void ClearManualHoldPoint()
    {
        _hasManualHold = false;
    }

    public bool HasManualHoldPoint => _hasManualHold;
    public Vector3 ManualHoldPoint => _manualHoldPoint;
    // -------------------- COMBAT STATE (read-only) --------------------
    // Exposed so CommandExecutor can avoid overriding movement while this unit is actively fighting,
    // and to allow "attack" orders to force a specific combat target.
    public Transform CurrentEnemyTarget => currentEnemy;

    /// <summary>
    /// Force this ally to engage a specific enemy target immediately (used by Attack/Follow orders).
    /// Clears follow-slot targeting so combat movement (standoff/strafe) is fully controlled by this script.
    /// </summary>
    public void ForceCombatTarget(Transform enemy)
    {
        if (enemy == null) return;
        if (TargetIsDeadOrInvalid(enemy)) return;

        // Clear any formation slot / follow target; combat should not be tethered.
        target = null;

        // Attack orders should not resume old destinations after combat.
        resumeWasFollowing = false;
        hasResumeDestination = false;

        chasing = true;
        currentEnemy = enemy;

        // Mark this as a player-commanded attack so we don't drop chase due to distanceToLose.
        _hasCommandedAttack = true;
        _commandedAttackTarget = enemy;
        _commandedAttackUntilTime = (commandedAttackChaseMaxSeconds <= 0f) ? Mathf.Infinity : (Time.time + commandedAttackChaseMaxSeconds);
        // Re-pick preferred range immediately when a direct attack order is issued.
        ResetDesiredAttackRangeCycle(pickImmediately: true);

        // Direct attack orders should feel active: temporarily disable the in-range pause so we keep repositioning/straffing.
        _forceStrafeUntilTime = Time.time + Mathf.Max(0f, forceStrafeAfterAttackOrderSeconds);

        // Reset combat pause cycle when we start/force a new engagement.
        _combatPauseTimer = 0f;
        _combatMoveBurstTimer = 0f;
    }

    /// <summary>
    /// Returns true if we should ignore distanceToLose for the current enemy (player-issued Attack order).
    /// This prevents the unit from "giving up" on long-distance commanded attacks and falling back to team-follow.
    /// </summary>
    private bool ShouldIgnoreLoseDistance(Transform enemy)
    {
        if (!allowCommandedAttackChaseBeyondLose) return false;
        if (!_hasCommandedAttack) return false;

        if (enemy == null)
        {
            _hasCommandedAttack = false;
            _commandedAttackTarget = null;
            return false;
        }

        // Only ignore lose distance for the same target that was commanded.
        if (_commandedAttackTarget != null && enemy != _commandedAttackTarget)
        {
            return false;
        }

        // Optional timeout.
        if (commandedAttackChaseMaxSeconds > 0f && Time.time > _commandedAttackUntilTime)
        {
            _hasCommandedAttack = false;
            _commandedAttackTarget = null;
            return false;
        }

        return true;
    }

    private void Update()
    {
        // Rotation:
        // If we let the agent rotate while we also rotate to face targets in combat,
        // the character can end up "running backwards" or snapping.
        // So we always rotate manually.
        if (agent != null)
        {
            agent.updateRotation = false;

            if (!chasing)
            {
                Vector3 vel = agent.desiredVelocity;
                vel.y = 0f;
                if (vel.sqrMagnitude > 0.001f)
                {
                    Quaternion look = Quaternion.LookRotation(vel.normalized, Vector3.up);
                    transform.rotation = Quaternion.Slerp(transform.rotation, look, Time.deltaTime * moveTurnSpeed);
                }
            }
        }

        // Keep agent speed in sync with team size (only when it changes).
        // (Prevents unexpected slowdowns if you tune speed in the Inspector.)
        if (agent != null && combatStats != null)
        {
            float desired = combatStats.GetMoveSpeed() * GetWaterMult();
            if (!Mathf.Approximately(agent.speed, desired))
                agent.speed = desired;
        }
        else if (agent != null && combatStats == null && enableWaterSlow)
        {
            // If no combat stats system is present, at least apply water slow using the agent's baseline speed.
            if (_baseAgentSpeedFallback <= 0f) _baseAgentSpeedFallback = agent.speed;
            float desired = _baseAgentSpeedFallback * GetWaterMult();
            if (!Mathf.Approximately(agent.speed, desired))
                agent.speed = desired;
        }

        // If we were chasing but the enemy was destroyed, stop chasing and resume.
        if (chasing && currentEnemy == null)
        {
            StopChasingAndResume();
        }

        // Acquire / validate target
        if (!chasing)
        {
            TryAcquireEnemy();
        }
        else
        {
            // If enemy ran far enough away, stop chasing and resume.
            if (currentEnemy == null)
            {
                StopChasingAndResume();
            }
            else
            {
                float dist = Vector3.Distance(transform.position, currentEnemy.position);

                // If we're in a manual hold zone (player-issued Move), never chase outside the leash.
                if (enableManualHoldZone && _hasManualHold)
                {
                    float leash = Mathf.Max(0.1f, manualChaseLeashRadius);
                    float dSelf = Vector3.Distance(transform.position, _manualHoldPoint);
                    float dEnemy = Vector3.Distance(currentEnemy.position, _manualHoldPoint);

                    if (dSelf > leash || dEnemy > leash)
                    {
                        StopChasingAndResume();
                        return;
                    }
                }

                if (dist > distanceToLose && !ShouldIgnoreLoseDistance(currentEnemy))
                {
                    StopChasingAndResume();
                }
                else
                {
                    ChaseAndShoot(currentEnemy);
                }
            }
        }

        // Follow travel target when not chasing (e.g., join in-route following a moving team)
        if (!chasing && target != null && agent != null)
        {
            // If we're on a team AND the player has set a team pin/rally point, do NOT keep chasing a teammate Transform.
            // This prevents "second ally follows the leader instead of the updated team location."
            if (TeamManager.Instance != null)
            {
                Team t = TeamManager.Instance.GetTeamOf(this.transform);
                if (t != null && TryGetLatestPinnedDestinationForTeam(t, out Vector3 teamPinned))
                {
                    // Only override if our current target is a teammate (anchor/member).
                    if (t.Contains(target))
                    {
                        target = null;
                        agent.isStopped = false;
                        agent.SetDestination(teamPinned);
                        travelFollowTimer = Mathf.Max(0.05f, travelFollowUpdateInterval);
                    }
                }
            }

            // Normal dynamic-follow behavior.
            if (target != null)
            {
                travelFollowTimer -= Time.deltaTime;
                if (travelFollowTimer <= 0f)
                {
                    agent.SetDestination(target.position);
                    travelFollowTimer = Mathf.Max(0.05f, travelFollowUpdateInterval);
                }
            }
        }

        // Face movement direction while traveling (prevents "running backwards" when agent rotation is off).
        if (!chasing && agent != null)
        {
            Vector3 v = agent.desiredVelocity;
            v.y = 0f;
            if (v.sqrMagnitude > 0.001f)
            {
                Quaternion look = Quaternion.LookRotation(v.normalized, Vector3.up);
                transform.rotation = Quaternion.Slerp(transform.rotation, look, Time.deltaTime * moveTurnSpeed);
            }
        }

        // Running animation
        // IMPORTANT:
        // During combat strafing we keep stoppingDistance ~= desiredAttackRange (ex: 6m).
        // That means agent.remainingDistance is often <= stoppingDistance even while the agent is moving,
        // which made "isRunning" stay false and the ally looked Idle while strafing.
        // Drive running from actual movement (velocity) instead.
        if (soldierAnimator != null && agent != null)
        {
            // Use actual movement to drive locomotion animation (works for combat strafing)
            float speed = 0f;
            if (!agent.isStopped)
            {
                // desiredVelocity leads during acceleration; velocity is actual.
                speed = Mathf.Max(agent.desiredVelocity.magnitude, agent.velocity.magnitude);
            }

            bool isMoving = speed > 0.05f;

            if (_animHasIsRunning)
                soldierAnimator.SetBool(_animIsRunningHash, isMoving);

            // If your controller uses a Speed float blend-tree, support that too.
            if (_animHasSpeed)
                soldierAnimator.SetFloat(_animSpeedHash, speed);
        }

        // Auto-clear the pinned move marker when we arrive at our pinned destination (fixed-point moves).
        // This avoids leaving move pins behind after the ally finishes moving.
        if (autoClearMoveMarkerOnArrival && !chasing && target == null && agent != null && !agent.pathPending)
        {
            // Only clear when we actually have a pinned destination for this unit.
            if (TryGetLatestPinnedDestinationForTeamOrUnit(out Vector3 pinnedDest))
            {
                float buffer = Mathf.Max(0f, markerArrivalBuffer);
                if (useTeamArrivalBufferMultiplier && TeamManager.Instance != null && TeamManager.Instance.GetTeamOf(this.transform) != null)
                {
                    buffer *= Mathf.Max(0.1f, teamArrivalBufferMultiplier);
                }
                float arriveDist = Mathf.Max(agent.stoppingDistance, 0.05f) + buffer;
                float d = Vector3.Distance(transform.position, pinnedDest);

                // We also require the agent to have effectively stopped to avoid clearing too early.
                bool stopped = agent.velocity.sqrMagnitude < 0.01f && agent.desiredVelocity.sqrMagnitude < 0.01f;
                if (d <= arriveDist && stopped)
                {
                    TryClearPinnedMoveMarker();
                }
            }
        }

        // Update pinned state (v1: pinned while chasing).
        if (pinnedStatus != null)
            pinnedStatus.SetPinned(chasing);
    }

    private void TryAcquireEnemy()
    {
        // If we're holding a player-issued move position and auto-aggro is disabled, do nothing.
        if (enableManualHoldZone && _hasManualHold && !manualHoldAllowsAutoAggro)
            return;

        Transform best = null;
        float bestDist = float.MaxValue;

        // 1) Team focus-fire: if a nearby teammate is already chasing something, prefer that target (with cooldown).
        if (enableTeamFocusFire && Time.time >= _nextFocusFireTime && TeamManager.Instance != null)
        {
            Team team = TeamManager.Instance.GetTeamOf(this.transform);
            if (team != null && team.Members != null && team.Members.Count > 1)
            {
                float maxTargetDist = Mathf.Max(0.1f, focusFireMaxTargetDistance);

                for (int i = 0; i < team.Members.Count; i++)
                {
                    Transform m = team.Members[i];
                    if (m == null || m == this.transform) continue;

                    AllyController other = m.GetComponent<AllyController>();
                    if (other == null || !other.IsChasing) continue;

                    Transform enemy = other.CurrentEnemy;
                    if (enemy == null) continue;
                    if (TargetIsDeadOrInvalid(enemy)) continue;

                    float d = Vector3.Distance(transform.position, enemy.position);
                    if (d > distanceToChase) continue;
                    if (d > maxTargetDist) continue;
                    if (d >= bestDist) continue;

                    // Manual-hold leash filter (don't focus-fire something outside our hold zone leash).
                    if (enableManualHoldZone && _hasManualHold)
                    {
                        float leash = Mathf.Max(0.1f, manualChaseLeashRadius);
                        float dEnemyToHold = Vector3.Distance(enemy.position, _manualHoldPoint);
                        if (dEnemyToHold > leash) continue;
                    }

                    bestDist = d;
                    best = enemy;
                }

                if (best != null)
                    _nextFocusFireTime = Time.time + Mathf.Max(0f, focusFireCooldown);
            }
        }

        // 2) Normal nearest-enemy search (fallback)
        if (best == null)
        {
            GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");

            for (int i = 0; i < enemies.Length; i++)
            {
                var go = enemies[i];
                if (go == null) continue;

                Transform t = go.transform;
                if (TargetIsDeadOrInvalid(t)) continue;
                float d = Vector3.Distance(transform.position, t.position);
                if (d >= distanceToChase) continue;
                if (d >= bestDist) continue;

                if (enableManualHoldZone && _hasManualHold)
                {
                    float leash = Mathf.Max(0.1f, manualChaseLeashRadius);
                    float dEnemyToHold = Vector3.Distance(t.position, _manualHoldPoint);
                    if (dEnemyToHold > leash) continue;
                }

                bestDist = d;
                best = t;
            }
        }

        if (best != null)
        {
            // entering chase: remember where we were going before combat
            resumeWasFollowing = (target != null);
            if (agent != null)
            {
                resumeDestination = agent.destination;
                hasResumeDestination = true;
            }

            chasing = true;
            currentEnemy = best;

            // Re-pick preferred range immediately on engagement start.
            ResetDesiredAttackRangeCycle(pickImmediately: true);

            // Reset combat pause cycle when we start a new engagement.
            _combatPauseTimer = 0f;
            _combatMoveBurstTimer = 0f;
        }
    }

    private void StopChasingAndResume()
    {
        _hasCommandedAttack = false;
        _commandedAttackTarget = null;
        chasing = false;
        currentEnemy = null;

        // If we were following a dynamic target (e.g., joining a moving team),
        // don't restore a stale point destination; the follow logic below will resume naturally.
        if (resumeWasFollowing && target != null)
        {
            hasResumeDestination = false;
            return;
        }

        if (agent == null) { hasResumeDestination = false; return; }

        // ✅ TEAM RESUME FIX (updated):
        // If the team has an active pinned destination (player moved the team star / rally point),
        // prefer that over following the Anchor Transform. This fixes: "joiner keeps following leader
        // instead of the updated team location set in command mode."
        if (TeamManager.Instance != null)
        {
            Team team = TeamManager.Instance.GetTeamOf(this.transform);
            if (team != null)
            {
                // 1) Prefer the TEAM pin (rally point) if present.
                if (TryGetLatestPinnedDestinationForTeam(team, out Vector3 teamPinned))
                {
                    // Clear any stale dynamic-follow target (otherwise we keep chasing a teammate).
                    target = null;

                    if (agent != null && agent.isActiveAndEnabled)
                    {
                        agent.isStopped = false;
                        agent.SetDestination(teamPinned);
                    }

                    hasResumeDestination = false;
                    resumeWasFollowing = false;
                    return;
                }

                // 2) Otherwise, do NOT blindly override an active path (formation/merge may have already assigned a slot).
                // If we have no path and we're meaningfully separated from the Anchor, regroup toward an offset near the Anchor
                // (not the exact center) to reduce pile-ups when teams merge.
                if (team.Anchor != null && team.Anchor != this.transform)
                {
                    // If TeamManager formation is enabled, never override destinations here.
                    // During merges, TeamManager.ApplyFormationAroundAnchor() assigns per-member slots;
                    // forcing a regroup destination causes everyone to converge and collide.
                    if (TeamManager.Instance != null && TeamManager.Instance.applyFormationOnTeamChange)
                    {
                        hasResumeDestination = false;
                        resumeWasFollowing = false;
                        return;
                    }

                    // If something else already issued a destination (eg. TeamManager formation), don't stomp it.
                    if (agent.hasPath || agent.pathPending)
                    {
                        hasResumeDestination = false;
                        resumeWasFollowing = false;
                        return;
                    }

                    Vector3 anchorPos = team.Anchor.position; anchorPos.y = 0f;
                    Vector3 myPos = this.transform.position; myPos.y = 0f;

                    float dist = Vector3.Distance(myPos, anchorPos);

                    // Only regroup if we're not already basically there.
                    if (dist > 0.75f)
                    {
                        // Deterministic offset per member so they don't all converge on the same point.
                        // Make this fairly large during merge/regroup so two allies don't "fight for the center".
                        int h = Mathf.Abs((team.Id * 73856093) ^ this.GetInstanceID());

                        // Base radius: prefer the team's formation radius, but never too small.
                        float r = Mathf.Max(2.25f, team.FormationRadius * 1.15f);

                        // Deterministic jitter (0..1m) so even two members get different offsets.
                        r += ((h % 100) / 100f) * 1.0f;

                        Vector3 dir = (myPos - anchorPos);
                        dir.y = 0f;

                        // Prefer pushing outward along the current radial direction (avoids crossing through the anchor),
                        // fall back to a deterministic angle if we're exactly on top of the anchor.
                        if (dir.sqrMagnitude < 0.01f)
                        {
                            float angle = (h % 360) * Mathf.Deg2Rad;
                            dir = new Vector3(Mathf.Cos(angle), 0f, Mathf.Sin(angle));
                        }
                        else
                        {
                            dir.Normalize();
                        }

                        Vector3 tangent = new Vector3(-dir.z, 0f, dir.x);
                        float side = (((h / 360) % 200) - 100) / 100f; // -1..1

                        Vector3 desired = anchorPos + (dir * r) + (tangent * (side * 0.75f));

                        // Snap to navmesh (use existing sample radii fields; avoid introducing a new undefined variable)
                        float regroupSampleRadius = Mathf.Max(0.25f, Mathf.Max(backoffSampleRadius, strafeSampleRadius));
                        if (NavMesh.SamplePosition(desired, out NavMeshHit regroupHit, regroupSampleRadius, NavMesh.AllAreas))
                            desired = regroupHit.position;

                        agent.isStopped = false;
                        agent.SetDestination(desired);
                    }

                    hasResumeDestination = false;
                    resumeWasFollowing = false;
                    return;
                }
            }
        }

        // If we have a manual hold point (player Move order), always return to it after combat.
        if (enableManualHoldZone && _hasManualHold && target == null)
        {
            agent.isStopped = false;
            agent.SetDestination(_manualHoldPoint);
            hasResumeDestination = false;
            return;
        }

        // ✅ KEY FIX:
        // If this unit has a pinned move destination (team/ally move pins), resume to the LATEST pinned destination.
        // This solves: "ally resumes to original team spot after combat even if team destination was updated".
        if (TryGetLatestPinnedDestinationForTeamOrUnit(out Vector3 pinnedDest))
        {
            agent.isStopped = false;
            agent.SetDestination(pinnedDest);
            hasResumeDestination = false;
            return;
        }

        // Otherwise, resume the previously commanded destination (e.g., move-to-point).
        if (hasResumeDestination)
        {
            agent.isStopped = false;
            agent.SetDestination(resumeDestination);
            hasResumeDestination = false;
        }
    }

    private bool TargetIsDeadOrInvalid(Transform t)
    {
        if (t == null) return true;

        // If the target object is disabled, treat as invalid.
        if (!t.gameObject.activeInHierarchy) return true;

        // If the target has a DeathController and is dead, invalid.
        var dc = t.GetComponentInParent<MnR.DeathController>();
        if (dc != null && dc.IsDead) return true;

        // If the target has Enemy2Controller and it's dead, invalid.
        var e2 = t.GetComponentInParent<Enemy2Controller>();
        if (e2 != null && e2.IsDead) return true;

        // If the target has EnemyHealthController and it's dead, invalid.
        var eh = t.GetComponentInParent<EnemyHealthController>();
        if (eh != null && eh.IsDead) return true;

        return false;
    }


    private bool TryGetLatestPinnedDestination(out Vector3 dest)
    {
        dest = default;

        // If your marker system isn't present, nothing to do.
        if (MoveDestinationMarkerSystem.Instance == null) return false;

        var inst = MoveDestinationMarkerSystem.Instance;
        var type = inst.GetType();

        // 1) If a public method exists, prefer it (future-proof).
        // We try common names without requiring you to change other files.
        // bool TryGetPinnedDestination(Transform unit, out Vector3 destination)
        // bool TryGetDestinationFor(Transform unit, out Vector3 destination)
        try
        {
            MethodInfo mi =
                type.GetMethod("TryGetPinnedDestination", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                ?? type.GetMethod("TryGetDestinationFor", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                ?? type.GetMethod("TryGetPinnedFor", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (mi != null)
            {
                object[] args = new object[] { this.transform, dest };
                // out param comes back in args[1]
                object okObj = mi.Invoke(inst, args);
                if (okObj is bool ok && ok)
                {
                    if (args[1] is Vector3 v)
                    {
                        dest = v;
                        return true;
                    }
                }
            }
        }
        catch
        {
            // ignore and fall back to reflection on fields
        }

        // 2) Fallback: reflect private Dictionary<Transform, Pinned> pinnedByUnit and read pinned.destination
        try
        {
            var field = type.GetField("pinnedByUnit", BindingFlags.Instance | BindingFlags.NonPublic);
            if (field == null) return false;

            var dictObj = field.GetValue(inst);
            if (dictObj == null) return false;

            // Dictionary<TKey,TValue> implements non-generic IDictionary
            var dict = dictObj as IDictionary;
            if (dict == null) return false;

            if (!dict.Contains(this.transform)) return false;

            var pinned = dict[this.transform];
            if (pinned == null) return false;

            var pType = pinned.GetType();

            // destination is a field in your current MoveDestinationMarkerSystem.Pinned class
            var destField = pType.GetField("destination", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (destField != null && destField.FieldType == typeof(Vector3))
            {
                dest = (Vector3)destField.GetValue(pinned);
                return true;
            }

            // or destination as a property
            var destProp = pType.GetProperty("destination", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (destProp != null && destProp.PropertyType == typeof(Vector3))
            {
                dest = (Vector3)destProp.GetValue(pinned);
                return true;
            }
        }
        catch
        {
            // ignore
        }

        return false;
    }

    private bool TryGetLatestPinnedDestinationForTeam(Team team, out Vector3 dest)
    {
        dest = default;
        if (team == null) return false;

        if (MoveDestinationMarkerSystem.Instance == null) return false;

        var inst = MoveDestinationMarkerSystem.Instance;
        var type = inst.GetType();

        // 1) If a method exists, prefer it.
        // Common patterns we try:
        // bool TryGetPinnedDestinationForTeam(Team team, out Vector3 destination)
        // bool TryGetPinnedDestinationForTeam(int teamId, out Vector3 destination)
        // bool TryGetDestinationForTeam(Team team, out Vector3 destination)
        try
        {
            MethodInfo mi =
                type.GetMethod("TryGetPinnedDestinationForTeam", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                ?? type.GetMethod("TryGetDestinationForTeam", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                ?? type.GetMethod("TryGetTeamPinnedDestination", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                ?? type.GetMethod("TryGetPinnedForTeam", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (mi != null)
            {
                var ps = mi.GetParameters();
                if (ps != null && ps.Length == 2 && ps[1].IsOut && ps[1].ParameterType == typeof(Vector3).MakeByRefType())
                {
                    // Param 0 could be Team or int teamId.
                    object[] args;
                    if (ps[0].ParameterType == typeof(Team))
                        args = new object[] { team, dest };
                    else if (ps[0].ParameterType == typeof(int))
                        args = new object[] { team.Id, dest };
                    else
                        args = null;

                    if (args != null)
                    {
                        object okObj = mi.Invoke(inst, args);
                        if (okObj is bool ok && ok)
                        {
                            if (args[1] is Vector3 v)
                            {
                                dest = v;
                                return true;
                            }
                        }
                    }
                }
            }
        }
        catch
        {
            // ignore and fall back
        }

        // 2) Fallback: reflect private dictionaries.
        // Possible field names: pinnedByTeam, pinnedByTeamId, pinnedByTeamIndex, pinnedByTeamKey
        try
        {
            FieldInfo field =
                type.GetField("pinnedByTeam", BindingFlags.Instance | BindingFlags.NonPublic)
                ?? type.GetField("pinnedByTeamId", BindingFlags.Instance | BindingFlags.NonPublic)
                ?? type.GetField("pinnedByTeamIndex", BindingFlags.Instance | BindingFlags.NonPublic)
                ?? type.GetField("pinnedByTeamKey", BindingFlags.Instance | BindingFlags.NonPublic);

            if (field == null) return false;

            object dictObj = field.GetValue(inst);
            if (dictObj == null) return false;

            var dict = dictObj as IDictionary;
            if (dict == null) return false;

            object key = null;
            if (dict.Contains(team)) key = team;
            else if (dict.Contains(team.Id)) key = team.Id;

            if (key == null) return false;

            var pinned = dict[key];
            if (pinned == null) return false;

            var pType = pinned.GetType();

            var destField = pType.GetField("destination", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (destField != null && destField.FieldType == typeof(Vector3))
            {
                dest = (Vector3)destField.GetValue(pinned);
                return true;
            }

            var destProp = pType.GetProperty("destination", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (destProp != null && destProp.PropertyType == typeof(Vector3))
            {
                dest = (Vector3)destProp.GetValue(pinned);
                return true;
            }
        }
        catch
        {
            // ignore
        }

        return false;
    }

    private bool TryGetLatestPinnedDestinationForTeamOrUnit(out Vector3 dest)
    {
        dest = default;

        // Prefer team pin if we are on a team.
        if (TeamManager.Instance != null)
        {
            Team team = TeamManager.Instance.GetTeamOf(this.transform);
            if (team != null && TryGetLatestPinnedDestinationForTeam(team, out dest))
                return true;
        }

        // Fallback to per-unit pin.
        return TryGetLatestPinnedDestination(out dest);
    }

    private void TryClearPinnedMoveMarker()
    {
        if (MoveDestinationMarkerSystem.Instance == null) return;

        var inst = MoveDestinationMarkerSystem.Instance;
        var type = inst.GetType();

        // Try a few common method signatures without hard dependencies.
        // Preferred (your project has used this pattern):
        //   ClearForUnits(GameObject[] units)
        // Also supports:
        //   ClearForUnit(Transform unit)
        //   ClearForUnits(Transform[] units)
        //   ClearFor(Transform unit)
        //   Unpin(Transform unit)
        try
        {
            // 1) ClearForUnits(GameObject[])
            var m = type.GetMethod("ClearForUnits", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (m != null)
            {
                var p = m.GetParameters();
                if (p.Length == 1)
                {
                    if (p[0].ParameterType == typeof(GameObject[]))
                    {
                        m.Invoke(inst, new object[] { new[] { this.gameObject } });
                        return;
                    }
                    if (p[0].ParameterType == typeof(Transform[]))
                    {
                        m.Invoke(inst, new object[] { new[] { this.transform } });
                        return;
                    }
                }
            }

            // 2) ClearForUnit(Transform)
            m = type.GetMethod("ClearForUnit", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (m != null)
            {
                var p = m.GetParameters();
                if (p.Length == 1 && p[0].ParameterType == typeof(Transform))
                {
                    m.Invoke(inst, new object[] { this.transform });
                    return;
                }
            }

            // 3) ClearFor(Transform)
            m = type.GetMethod("ClearFor", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (m != null)
            {
                var p = m.GetParameters();
                if (p.Length == 1 && p[0].ParameterType == typeof(Transform))
                {
                    m.Invoke(inst, new object[] { this.transform });
                    return;
                }
            }

            // 4) Unpin(Transform)
            m = type.GetMethod("Unpin", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (m != null)
            {
                var p = m.GetParameters();
                if (p.Length == 1 && p[0].ParameterType == typeof(Transform))
                {
                    m.Invoke(inst, new object[] { this.transform });
                    return;
                }
            }
        }
        catch
        {
            // If reflection fails, do nothing. Marker will remain until cleared elsewhere.
        }
    }

    private float GetEffectiveFormationTether()
    {
        float tether = Mathf.Max(0f, formationCombatTetherRadius);
        if (!scaleTetherWithTeamSize || tether <= 0f) return tether;

        int teamSize = 0;

        // Use reflection to avoid hard-coupling to a specific Team API shape.
        try
        {
            if (TeamManager.Instance != null)
            {
                var tm = TeamManager.Instance;
                var tmType = tm.GetType();

                var getTeamOf = tmType.GetMethod("GetTeamOf", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (getTeamOf != null)
                {
                    object teamObj = getTeamOf.Invoke(tm, new object[] { this.transform });
                    if (teamObj != null)
                    {
                        var tType = teamObj.GetType();

                        // Common: Members (List<Transform> or List<AllyController> etc.)
                        var membersField = tType.GetField("Members", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        if (membersField != null)
                        {
                            if (membersField.GetValue(teamObj) is System.Collections.ICollection col)
                                teamSize = col.Count;
                        }
                        else
                        {
                            var membersProp = tType.GetProperty("Members", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                            if (membersProp != null)
                            {
                                var val = membersProp.GetValue(teamObj);
                                if (val is System.Collections.ICollection col2)
                                    teamSize = col2.Count;
                            }
                        }

                        // Fallback: "members" lowercase
                        if (teamSize == 0)
                        {
                            var membersField2 = tType.GetField("members", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                            if (membersField2 != null)
                            {
                                if (membersField2.GetValue(teamObj) is System.Collections.ICollection col3)
                                    teamSize = col3.Count;
                            }
                            else
                            {
                                var membersProp2 = tType.GetProperty("members", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                                if (membersProp2 != null)
                                {
                                    var val2 = membersProp2.GetValue(teamObj);
                                    if (val2 is System.Collections.ICollection col4)
                                        teamSize = col4.Count;
                                }
                            }
                        }
                    }
                }
            }
        }
        catch
        {
            // ignore; use base tether
        }

        if (teamSize > 1)
            tether += Mathf.Max(0f, tetherExtraPerSqrtMember) * Mathf.Sqrt(teamSize - 1);

        return tether;
    }

    private Vector3 ClampCombatMoveToFormation(Vector3 desired, Transform formationSlot)
    {
        if (!holdFormationWhenFollowing) return desired;
        if (formationSlot == null) return desired;

        float tether = GetEffectiveFormationTether();
        if (tether <= 0.001f) return formationSlot.position;

        Vector3 anchor = formationSlot.position;
        Vector3 off = desired - anchor;
        off.y = 0f;

        float mag = off.magnitude;
        if (mag <= tether) return desired;

        Vector3 clamped = anchor + off.normalized * tether;
        clamped.y = desired.y;
        return clamped;
    }

    // -------------------- DYNAMIC DESIRED RANGE --------------------
    private void InitializeDesiredAttackRangeRuntime()
    {
        _currentDesiredAttackRangeRuntime = Mathf.Max(0.5f, desiredAttackRange);
        _nextDesiredAttackRangeUpdateTime = Time.time + GetNextDesiredRangeInterval();
    }

    private float GetNextDesiredRangeInterval()
    {
        float a = Mathf.Max(0.05f, desiredAttackRangeUpdateIntervalMin);
        float b = Mathf.Max(a, desiredAttackRangeUpdateIntervalMax);
        return Random.Range(a, b);
    }

    private void ResetDesiredAttackRangeCycle(bool pickImmediately)
    {
        if (!enableDynamicDesiredAttackRange) return;

        if (pickImmediately)
            _nextDesiredAttackRangeUpdateTime = Time.time; // forces an immediate repick on next update
        else
            _nextDesiredAttackRangeUpdateTime = Time.time + GetNextDesiredRangeInterval();
    }

    private void UpdateDesiredAttackRangeRuntime(bool useBand, float bandMin, float bandMax)
    {
        if (!enableDynamicDesiredAttackRange)
        {
            _currentDesiredAttackRangeRuntime = Mathf.Max(0.5f, desiredAttackRange);
            return;
        }

        if (desiredAttackRangeUpdateOnlyWhenChasing && !chasing)
            return;

        if (Time.time < _nextDesiredAttackRangeUpdateTime)
            return;

        _nextDesiredAttackRangeUpdateTime = Time.time + GetNextDesiredRangeInterval();

        if (useBand)
        {
            _currentDesiredAttackRangeRuntime = Random.Range(bandMin, bandMax);
        }
        else
        {
            float baseRange = Mathf.Max(0.5f, desiredAttackRange);
            float j = Mathf.Max(0f, desiredAttackRangeJitter);
            _currentDesiredAttackRangeRuntime = Mathf.Max(0.5f, baseRange + Random.Range(-j, j));
        }
    }

    private float GetCurrentDesiredAttackRange(bool useBand, float bandMin, float bandMax)
    {
        float r = enableDynamicDesiredAttackRange ? _currentDesiredAttackRangeRuntime : desiredAttackRange;
        r = Mathf.Max(0.5f, r);
        if (useBand) r = Mathf.Clamp(r, bandMin, bandMax);
        return r;
    }

    private bool TryGetCombatRangeBand(out float minRange, out float maxRange)
    {
        // Returns true if the min/max range band is valid and enabled.
        minRange = Mathf.Max(0.5f, desiredAttackRangeMin);
        maxRange = Mathf.Max(minRange, desiredAttackRangeMax);

        if (!enableDesiredAttackRangeBand) return false;

        // Require a meaningful band.
        if (maxRange <= minRange + 0.01f) return false;

        return true;
    }

    private Vector3 ClampToCombatRangeBandOnNavMesh(Vector3 desired, Vector3 targetPoint, float minRange, float maxRange, float sampleRadius)
    {
        // Adjust 'desired' so its horizontal distance to targetPoint stays within [minRange, maxRange],
        // then sample onto the NavMesh to avoid unreachable points.
        Vector3 flat = desired - targetPoint;
        flat.y = 0f;

        if (flat.sqrMagnitude < 0.0001f)
        {
            flat = (transform.position - targetPoint);
            flat.y = 0f;
            if (flat.sqrMagnitude < 0.0001f)
                flat = transform.forward;
        }

        float mag = flat.magnitude;
        float clamped = Mathf.Clamp(mag, minRange, maxRange);

        Vector3 adjusted = targetPoint + flat.normalized * clamped;
        adjusted.y = desired.y;

        if (NavMesh.SamplePosition(adjusted, out NavMeshHit hit, Mathf.Max(0.25f, sampleRadius), NavMesh.AllAreas))
            adjusted = hit.position;

        return adjusted;
    }

    private Vector3 GetAimPosition(Transform target)
    {
        if (target == null) return transform.position + (Vector3.up * aimHeightOffset);

        // 1) Preferred: explicit AimPoint child.
        if (!string.IsNullOrWhiteSpace(aimPointChildName))
        {
            Transform aimChild = target.Find(aimPointChildName);
            if (aimChild != null) return aimChild.position;
        }

        // 2) Next: collider bounds center (usually torso-ish).
        if (useColliderBoundsForAim)
        {
            Collider c = target.GetComponentInChildren<Collider>();
            if (c != null) return c.bounds.center;
        }

        // 3) Fallback: target pivot + vertical offset.
        return target.position + (Vector3.up * aimHeightOffset);
    }

    private void ChaseAndShoot(Transform enemy)
    {
        if (enemy == null) return;
        if (TargetIsDeadOrInvalid(enemy)) { StopChasingAndResume(); return; }

        Vector3 targetPoint = GetAimPosition(enemy);

        // Range gate variables (used to decide when we're allowed to actually fire).
        bool useBand = false;
        float minRange = 0f;
        float maxRange = 0f;
        bool useDynamicRange = enableDynamicDesiredAttackRange;

        // Desired range (single value or derived from band)
        float range = desiredAttackRange;

        // Distance is re-evaluated later too, but we initialize it here for movement logic.
        float dist = Vector3.Distance(transform.position, targetPoint);

        // If we're following a formation slot (PlayerSquadFollowSystem sets AllyController.target to a slot transform),
        // keep combat movement tethered to that slot so we don't break formation.
        Transform formationSlot = (target != null) ? target : null;

        // Maintain a stable standoff distance instead of running into the target's center.
        // NOTE: We manage standoff in code; do NOT set agent.stoppingDistance = desiredAttackRange.
        // If stoppingDistance is huge (ex: 24), the agent will think it's "already arrived" at most strafe points
        // and it won't move (and your run animation never triggers). Keep stoppingDistance small.
        if (agent != null)
        {
            // Optional min/max band (ex: keep between 20 and 60).
            useBand = TryGetCombatRangeBand(out minRange, out maxRange);

            // Optionally re-pick the preferred distance every couple seconds.
            UpdateDesiredAttackRangeRuntime(useBand, minRange, maxRange);

            range = GetCurrentDesiredAttackRange(useBand, minRange, maxRange);

            // Let the agent actually travel to strafe points.
            // We still maintain standoff ourselves via range/buffer logic.
            // Keep stoppingDistance SMALL so the agent doesn't think it's "already arrived" at most strafe points.
            float stopBase = (useBand && !enableDynamicDesiredAttackRange)
                ? Mathf.Clamp((minRange + maxRange) * 0.5f, 0.5f, 50f)
                : range;
            float combatStop = Mathf.Clamp(stopBase * 0.25f, 0.1f, 1.25f);
            if (!Mathf.Approximately(agent.stoppingDistance, combatStop))
                agent.stoppingDistance = combatStop;

            // Face target (flat) while fighting.
            Vector3 flatDir = targetPoint - transform.position;
            flatDir.y = 0f;
            if (flatDir.sqrMagnitude > 0.001f)
            {
                Quaternion look = Quaternion.LookRotation(flatDir.normalized, Vector3.up);
                transform.rotation = Quaternion.Slerp(transform.rotation, look, Time.deltaTime * faceTargetTurnSpeed);
            }

            dist = Vector3.Distance(transform.position, targetPoint);

            // Too far: move in toward a ring around the enemy (not the exact center).
            useDynamicRange = enableDynamicDesiredAttackRange;

            if ((useBand && !useDynamicRange) ? (dist > maxRange + attackRangeBuffer) : (dist > range + attackRangeBuffer))
            {
                // Out of ideal range: reset pause cycle so we don't get stuck "paused" while needing to reposition.
                _combatPauseTimer = 0f;
                _combatMoveBurstTimer = 0f;

                agent.isStopped = false;
                Vector3 toward = (targetPoint - transform.position);
                toward.y = 0f;
                if (toward.sqrMagnitude < 0.001f) toward = transform.forward;

                float approachRange = (useBand && !useDynamicRange) ? maxRange : range;

                Vector3 ringPoint = targetPoint - toward.normalized * approachRange;

                // Spread approach points a bit per-ally so teams don't all stack on the same ring point.
                Vector3 right = Vector3.Cross(Vector3.up, toward.normalized);
                float spread = Mathf.Clamp(((useBand && !useDynamicRange) ? maxRange : range) * 0.15f, 1f, 6f);
                float seed = (GetInstanceID() * 0.1234f);
                float side = Mathf.Sin(seed) * spread;
                ringPoint += right * side;
                ringPoint = ClampCombatMoveToFormation(ringPoint, formationSlot);
                if (useBand)
                    ringPoint = ClampToCombatRangeBandOnNavMesh(ringPoint, targetPoint, minRange, maxRange, strafeSampleRadius);
                agent.SetDestination(ringPoint);
            }
            // Too close: back off a bit.
            else if ((useBand && !useDynamicRange) ? (dist < minRange - attackRangeBuffer) : (dist < range - attackRangeBuffer))
            {
                // Too close: reset pause cycle so we can immediately back off.
                _combatPauseTimer = 0f;
                _combatMoveBurstTimer = 0f;

                Vector3 away = (transform.position - targetPoint);
                away.y = 0f;
                away = away.sqrMagnitude < 0.001f ? transform.forward : away.normalized;

                float backoffBase = (useBand && !useDynamicRange) ? minRange : range;

                float push = (backoffBase - dist) + 0.5f;
                Vector3 desired = transform.position + away * push;

                if (NavMesh.SamplePosition(desired, out NavMeshHit hit, backoffSampleRadius, NavMesh.AllAreas))
                    desired = hit.position;

                desired = ClampCombatMoveToFormation(desired, formationSlot);
                if (useBand)
                    desired = ClampToCombatRangeBandOnNavMesh(desired, targetPoint, minRange, maxRange, backoffSampleRadius);
                agent.isStopped = false;
                agent.SetDestination(desired);
            }
            // In range: optionally strafe/circle while shooting (more dynamic combat).
            else
            {
                if (enableCombatStrafe)
                {
                    // NEW: Pause / stand-ground behavior to reduce constant running around.
                    bool allowPause = pauseWhileShootingInRange && (Time.time >= _forceStrafeUntilTime);
                    if (allowPause)
                    {
                        // Initialize pause timer on first entry.
                        if (_combatPauseTimer <= 0f && _combatMoveBurstTimer <= 0f)
                            _combatPauseTimer = Random.Range(Mathf.Max(0f, pauseShootMinSeconds), Mathf.Max(pauseShootMinSeconds, pauseShootMaxSeconds));

                        // 1) Stand still and shoot for 2-3 seconds
                        if (_combatPauseTimer > 0f)
                        {
                            _combatPauseTimer -= Time.deltaTime;
                            agent.isStopped = true;
                            agent.ResetPath();
                        }
                        // 2) Then allow a short movement burst (strafe repath) before pausing again
                        else
                        {
                            if (_combatMoveBurstTimer <= 0f)
                            {
                                _combatMoveBurstTimer = Mathf.Max(0.05f, pauseMoveBurstSeconds);
                                _strafeRepathTimer = 0f; // force a new strafe point immediately
                            }

                            _combatMoveBurstTimer -= Time.deltaTime;

                            // Normal strafe timers
                            _strafeRepathTimer -= Time.deltaTime;
                            _strafeChangeTimer -= Time.deltaTime;

                            if (_strafeChangeTimer <= 0f)
                            {
                                // Occasionally flip sides so it doesn't look too robotic.
                                if (Random.value < 0.35f) _strafeSide *= -1;
                                _strafeAngleOffset = Random.Range(-strafeAngleJitter, strafeAngleJitter);
                                _strafeChangeTimer = Mathf.Max(0.1f, strafeChangeInterval);
                            }

                            if (_strafeRepathTimer <= 0f)
                            {
                                Vector3 toTarget = (targetPoint - transform.position);
                                toTarget.y = 0f;
                                if (toTarget.sqrMagnitude < 0.001f)
                                    toTarget = transform.forward;

                                Vector3 forwardToTarget = toTarget.normalized;

                                // Tangential (left/right) component around the target
                                Quaternion rot = Quaternion.AngleAxis((_strafeSide * 90f) + _strafeAngleOffset, Vector3.up);
                                Vector3 tangent = rot * forwardToTarget;

                                // Radial (toward/away) component to create diagonal motion ("left/right" + "up/down")
                                float radialSign = Random.Range(-1f, 1f); // negative = away, positive = toward
                                Vector3 moveDir = (tangent * Mathf.Max(0f, combatBurstTangentialWeight)) +
                                                 (forwardToTarget * radialSign * Mathf.Max(0f, combatBurstRadialWeight));

                                if (moveDir.sqrMagnitude < 0.0001f)
                                    moveDir = tangent;

                                moveDir.Normalize();

                                float step = Mathf.Max(0.25f, combatBurstMoveDistance);
                                Vector3 desired = transform.position + moveDir * step;

                                if (NavMesh.SamplePosition(desired, out NavMeshHit hit, strafeSampleRadius, NavMesh.AllAreas))
                                    desired = hit.position;

                                if (useBand)
                                    desired = ClampToCombatRangeBandOnNavMesh(desired, targetPoint, minRange, maxRange, strafeSampleRadius);

                                desired = ClampCombatMoveToFormation(desired, formationSlot);
                                if (useBand)
                                    desired = ClampToCombatRangeBandOnNavMesh(desired, targetPoint, minRange, maxRange, strafeSampleRadius);
                                agent.isStopped = false;
                                agent.SetDestination(desired);
                                _strafeRepathTimer = Mathf.Max(0.05f, strafeRepathInterval);
                            }

                            // End burst → start a new pause cycle
                            if (_combatMoveBurstTimer <= 0f)
                            {
                                _combatMoveBurstTimer = 0f;
                                _combatPauseTimer = Random.Range(Mathf.Max(0f, pauseShootMinSeconds), Mathf.Max(pauseShootMinSeconds, pauseShootMaxSeconds));
                                agent.isStopped = true;
                                agent.ResetPath();
                            }
                        }
                    }
                    else
                    {
                        // Original continuous strafe behavior
                        _strafeRepathTimer -= Time.deltaTime;
                        _strafeChangeTimer -= Time.deltaTime;

                        if (_strafeChangeTimer <= 0f)
                        {
                            // Occasionally flip sides so it doesn't look too robotic.
                            if (Random.value < 0.35f) _strafeSide *= -1;
                            _strafeAngleOffset = Random.Range(-strafeAngleJitter, strafeAngleJitter);
                            _strafeChangeTimer = Mathf.Max(0.1f, strafeChangeInterval);
                        }

                        if (_strafeRepathTimer <= 0f)
                        {
                            Vector3 fromTarget = (transform.position - targetPoint);
                            fromTarget.y = 0f;
                            if (fromTarget.sqrMagnitude < 0.001f)
                                fromTarget = transform.forward;

                            // Tangent around the target (left/right) plus small random angle jitter.
                            Quaternion rot = Quaternion.AngleAxis((_strafeSide * 90f) + _strafeAngleOffset, Vector3.up);
                            Vector3 strafeDir = rot * fromTarget.normalized;

                            float strafeRingRadius = useBand ? Mathf.Clamp(range, minRange, maxRange) : range;

                            Vector3 desired = targetPoint + strafeDir.normalized * strafeRingRadius;
                            if (NavMesh.SamplePosition(desired, out NavMeshHit hit, strafeSampleRadius, NavMesh.AllAreas))
                                desired = hit.position;

                            if (useBand)
                                desired = ClampToCombatRangeBandOnNavMesh(desired, targetPoint, minRange, maxRange, strafeSampleRadius);

                            desired = ClampCombatMoveToFormation(desired, formationSlot);
                            if (useBand)
                                desired = ClampToCombatRangeBandOnNavMesh(desired, targetPoint, minRange, maxRange, strafeSampleRadius);
                            agent.isStopped = false;
                            agent.SetDestination(desired);
                            _strafeRepathTimer = Mathf.Max(0.05f, strafeRepathInterval);
                        }
                    }
                }
                else
                {
                    // No strafe: stand still at ideal range.
                    _combatPauseTimer = 0f;
                    _combatMoveBurstTimer = 0f;

                    agent.isStopped = true;
                    agent.ResetPath();
                }
            }
        }

        // Recompute distance (agent/transform may have moved since last frame).
        dist = Vector3.Distance(transform.position, targetPoint);

        // ✅ IMPORTANT: Don't shoot unless we're close enough.
        if (onlyShootWhenInDesiredAttackRange && !IsWithinShootRange(dist, useBand, minRange, maxRange, range, useDynamicRange))
            return;

        // Fire
        fireCount -= Time.deltaTime;
        if (fireCount > 0) return;

        fireCount = fireRate;

        if (firePoint != null)
            firePoint.LookAt(targetPoint + new Vector3(0f, 0.5f, 0f));

        Vector3 targetDir = targetPoint - transform.position;
        float angle = Vector3.SignedAngle(targetDir, transform.forward, Vector3.up);

        if (Mathf.Abs(angle) < 30f)
        {
            if (bullet != null && firePoint != null)
            {
                GameObject spawned = Instantiate(bullet, firePoint.position, firePoint.rotation);
                TriggerMuzzleFlashSimple();

                // Set bullet damage from AllyCombatStats (team size scaling).
                BulletController bc = spawned.GetComponent<BulletController>();
                if (bc != null)
                {
                                        bc.owner = transform;
if (combatStats != null)
                        bc.Damage = combatStats.GetDamageInt();

                    bc.owner = transform;
                    // Ally bullets should damage enemies, not allies.
                    bc.damageEnemy = true;
                    bc.damageAlly = false;
                }
            }

            if (soldierAnimator != null)
                soldierAnimator.SetTrigger("Shoot");
        }
    }


    private bool IsWithinShootRange(float dist, bool useBand, float minRange, float maxRange, float range, bool useDynamicRange)
    {
        float shootBuf = Mathf.Max(0f, attackRangeBuffer + shootRangeExtraBuffer);

        // If we're using a min/max band AND we're not dynamically moving the desired range,
        // then we only shoot while inside the band (with buffers).
        if (useBand && !useDynamicRange)
            return dist <= (maxRange + shootBuf) && dist >= (minRange - shootBuf);

        // Otherwise, shoot when within the current desired range (plus buffers).
        return dist <= (range + shootBuf);
    }

    private void TriggerMuzzleFlashSimple()
    {
        if (muzzleFlashObject == null) return;

        if (muzzleFlashFollowFirePoint && firePoint != null)
        {
            muzzleFlashObject.transform.position = firePoint.TransformPoint(muzzleFlashLocalOffset);
            muzzleFlashObject.transform.rotation = firePoint.rotation;
        }
        // Reset active state so the flash is noticeable even if it was left on.
        if (muzzleFlashObject.activeSelf)
            muzzleFlashObject.SetActive(false);

        muzzleFlashObject.SetActive(true);

        if (_muzzleFlashRoutine != null)
            StopCoroutine(_muzzleFlashRoutine);

        _muzzleFlashRoutine = StartCoroutine(DisableMuzzleFlashAfterDelay());
    }

    private IEnumerator DisableMuzzleFlashAfterDelay()
    {
        yield return new WaitForSeconds(Mathf.Max(0.005f, muzzleFlashDuration));
        if (muzzleFlashObject != null)
            muzzleFlashObject.SetActive(false);
        _muzzleFlashRoutine = null;
    }

    // Optional: call this from an Animation Event on the fire frame
    public void AnimEvent_MuzzleFlash()
    {
        TriggerMuzzleFlashSimple();
    }
}